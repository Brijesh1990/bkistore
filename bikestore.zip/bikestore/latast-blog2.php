
<!--menu end-->
<script>
$(window).scroll(function() {
  if ($(this).scrollTop() > 211){
    $('header .header_menu').addClass("sticky_header");
  } else{
    $('header .header_menu').removeClass("sticky_header");
  }
});
</script>
<!---------catagory-banner-------->
<div class="main_breadcrumb">
	<div class="container-fluid">
		<div class="row">
		 <ul class="breadcrumb">
		   <h3>Bike News Roundup: The Future Of Mobility</h3>
						<li><a href="<?php echo $mainurl;?>/">Home</a></li>
						<li><a href="<?php echo $mainurl;?>/Blog">Bike News Roundup: The Future Of Mobility</a></li>
					  </ul>
		</div>
	</div>
</div><!------catagry banner end------>
<div id="blog-wrapper" class="blog-wrapper inner-blog-wrapper">
<div class="container-fluid">
  <div class="row eblog" ><aside id="column-left" class="col-sm-3 hidden-xs">
    <div class="search popular_posts">
	<h4 class="">Latest Blog</h4>
	<div id="blog_sidebar0" class="owl-carousel">
				<div class="">
						<div class="popular_posts_section">
			 				<div class="popular_posts_images">
					<a href="#"><img alt="Bike News Roundup: T.." title="Bike News Roundup: T.." class="img-responsive" src="<?php echo $baseurl;?>image/EB2.jpg"/></a>
				</div>
			 				<div class="popular_posts_text">
					<h5><a href="#">Bike News Roundup: T..</a></h5>
					<Span>By Admin</Span>
					<span>						<a href="#">23 Apr,2019</a>
						</span>
				</div>
			</div>
						<div class="popular_posts_section">
			 				<div class="popular_posts_images">
					<a href="#"><img alt="Bike News Roundup: T.." title="Bike News Roundup: T.." class="img-responsive" src="<?php echo $baseurl;?>image/EB1.jpg"/></a>
				</div>
			 				<div class="popular_posts_text">
					<h5><a href="#">Bike News Roundup: T..</a></h5>
					<Span>By Ashley Wick</Span>
					<span>						<a href="#">23 Apr,2019</a>
						</span>
				</div>
			</div>
						<div class="popular_posts_section">
			 				<div class="popular_posts_images">
					<a href="#"><img alt="Bike News Roundup: T.." title="Bike News Roundup: T.." class="img-responsive" src="<?php echo $baseurl;?>image/EB3.jpg"/></a>
				</div>
			 				<div class="popular_posts_text">
					<h5><a href="#">Bike News Roundup: T..</a></h5>
					<Span>By Ashley Wick</Span>
					<span>						<a href="#">23 Apr,2019</a>
						</span>
				</div>
			</div>
					</div>
				<div class="">
						<div class="popular_posts_section">
			 				<div class="popular_posts_images">
					<a href="#"><img alt="Bike News Roundup: T.." title="Bike News Roundup: T.." class="img-responsive" src="<?php echo $baseurl;?>image/EB4.jpg"/></a>
				</div>
			 				<div class="popular_posts_text">
					<h5><a href="#">Bike News Roundup: T..</a></h5>
					<Span>By Admin</Span>
					<span>						<a href="#">23 Apr,2019</a>
						</span>
				</div>
			</div>
					</div>
			</div>
</div>

  <script>
$(document).ready(function(){
	$('#blog_sidebar0').owlCarousel({
		items: 1,
		itemsDesktop:[1199,1],
		itemsDesktopSmall:[992,1],
		itemsTablet:[768,1],
		itemsMobile:[450,1],
		pagination: false,
		navigation: true,
		navigationText: ['<i class="fa fa-angle-left fa-5x"></i>', '<i class="fa fa-angle-right fa-5x"></i>']
	});
});   
</script>
    <div class="search popular_posts">
	<h4 class="">Popular Posts</h4>
	<div id="blog_sidebar1" class="owl-carousel">
				<div class="">
						<div class="popular_posts_section">
			 				<div class="popular_posts_images">
					<a href="#"><img alt="Bike News Roundup: T.." title="Bike News Roundup: T.." class="img-responsive" src="<?php echo $baseurl;?>image/EB2.jpg"/></a>
				</div>
			 				<div class="popular_posts_text">
					<h5><a href="#">Bike News Roundup: T..</a></h5>
					<Span>By Admin</Span>
					<span>						<a href="#">23 Apr,2019</a>
						</span>
				</div>
			</div>
						<div class="popular_posts_section">
			 				<div class="popular_posts_images">
					<a href="#"><img alt="Bike News Roundup: T.." title="Bike News Roundup: T.." class="img-responsive" src="<?php echo $baseurl;?>image/EB3.jpg"/></a>
				</div>
			 				<div class="popular_posts_text">
					<h5><a href="#">Bike News Roundup: T..</a></h5>
					<Span>By Ashley Wick</Span>
					<span>						<a href="#">23 Apr,2019</a>
						</span>
				</div>
			</div>
						<div class="popular_posts_section">
			 				<div class="popular_posts_images">
					<a href="#"><img alt="Bike News Roundup: T.." title="Bike News Roundup: T.." class="img-responsive" src="<?php echo $baseurl;?>image/EB1.jpg"/></a>
				</div>
			 				<div class="popular_posts_text">
					<h5><a href="#">Bike News Roundup: T..</a></h5>
					<Span>By Ashley Wick</Span>
					<span>						<a href="#">23 Apr,2019</a>
						</span>
				</div>
			</div>
					</div>
			</div>
</div>

  <script>
$(document).ready(function(){
	$('#blog_sidebar1').owlCarousel({
		items: 1,
		itemsDesktop:[1199,1],
		itemsDesktopSmall:[992,1],
		itemsTablet:[768,1],
		itemsMobile:[450,1],
		pagination: false,
		navigation: true,
		navigationText: ['<i class="fa fa-angle-left fa-5x"></i>', '<i class="fa fa-angle-right fa-5x"></i>']
	});
});   
</script>
  </aside>

                <div id="content" class="col-sm-9">
	
      <div class="row">
			     <div class="openthumbs">
                        <a href="image/EB2.jpg" title="Bike News Roundup: The Future of Mobility"><img src="<?php echo $baseurl;?>image/EB2.jpg" title="Bike News Roundup: The Future of Mobility" alt="Bike News Roundup: The Future of Mobility"></a>
                        			<div class="subimages">
								<div class="col-sm-3 images_silde"><a href="<?php echo $baseurl;?>image/EB1.jpg" title="Bike News Roundup: The Future of Mobility"> <img src="<?php echo $baseurl;?>image/EB1.jpg" title="Bike News Roundup: The Future of Mobility" alt="Bike News Roundup: The Future of Mobility"></a></div>
								<div class="col-sm-3 images_silde"><a href="<?php echo $baseurl;?>image/EB3.jpg" title="Bike News Roundup: The Future of Mobility"> <img src="<?php echo $baseurl;?>image/EB3.jpg" title="Bike News Roundup: The Future of Mobility" alt="Bike News Roundup: The Future of Mobility"></a></div>
								<div class="col-sm-3 images_silde"><a href="<?php echo $baseurl;?>image/EB4.jpg" title="Bike News Roundup: The Future of Mobility"> <img src="<?php echo $baseurl;?>image/EB4.jpg" title="Bike News Roundup: The Future of Mobility" alt="Bike News Roundup: The Future of Mobility"></a></div>
								<div class="col-sm-3 images_silde"><a href="<?php echo $baseurl;?>image/EB2.jpg" title="Bike News Roundup: The Future of Mobility"> <img src="<?php echo $baseurl;?>image/EB2.jpg" title="Bike News Roundup: The Future of Mobility" alt="Bike News Roundup: The Future of Mobility"></a></div>
							</div>

			<div class="clear"></div>
                      </div>
          		  
		  <h3 class="mail_page_hadding">Bike News Roundup: The Future of Mobility</h3>
	  <div class="row shear_and_editer">
		  <div class="col-sm-6">
			<div class="update_post_text">
			<ul class="fullblogcomments">
				<li><a href="#"><i class="fa fa-user"></i> <span>Admin</span></a></li>
				<li><i class="fa fa-clock-o"></i> <span>23 April, 2019</span></li>
				<li><i class="fa fa-eye"></i> <span>106</span></li>
				<li><i class="fa fa-comments-o"></i> <span>0</span></li>
			</ul>
			</div>
		  </div>
		  <div class="col-sm-6">
		  <div class="shear_social_media">
			<!-- AddThis Button BEGIN -->
            <div class="addthis_toolbox addthis_default_style" data-url="
            #"><a class="addthis_button_facebook_like" fb:like:layout="button_count"></a> <a class="addthis_button_tweet"></a> <a class="addthis_button_pinterest_pinit"></a> <a class="addthis_counter addthis_pill_style"></a></div>
            <script type="<?php echo $baseurl;?>text/javascript" src="<?php echo $baseurl;?>//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-515eeaf54693130e"></script> 
            <!-- AddThis Button END -->
					  </div>
		  </div>
		  </div>

		  <div class="update_post_text">
			<p></p><p> It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p><p></p>
			<p class="dec_tags">
			 
						</p><p><span><i class="fa fa-tags"></i> Tags</span>
						 <a href="#">Bike News Roundup: The Future of Mobility</a> 						 <a href=""></a> 			 </p>
						<p></p>
		 </div>
		 <hr>
		              <form class="form-horizontal" id="form-comment">
                <div id="comment"><p></p>
 </div>
                <h2>Write a Comment</h2>
                                <div class="form-group required">
                  <div class="col-sm-12">
                    <label class="control-label" for="input-name" style="float:left;">Your Name</label>
                    <input type="text" name="name" value="" id="input-name" class="form-control">
                  </div>
                </div>
                <div class="form-group required">
                  <div class="col-sm-12">
                    <label class="control-label" for="input-comment" style="float:left;">Your Comment</label>
                    <textarea name="text" rows="5" id="input-comment" class="form-control"></textarea>
                    <div class="help-block"><span class="text-danger">Note:</span> HTML is not translated!</div>
                  </div>
                </div>
				                <div class="form-group required">
                  <div class="col-sm-12">
                    <label class="control-label" style="float:left;">Rating
                    &nbsp;&nbsp;&nbsp; Bad&nbsp;
                    <input type="radio" name="rating" value="1">
                    &nbsp;
                    <input type="radio" name="rating" value="2">
                    &nbsp;
                    <input type="radio" name="rating" value="3">
                    &nbsp;
                    <input type="radio" name="rating" value="4">
                    &nbsp;
                    <input type="radio" name="rating" value="5">
                    &nbsp;Good</label></div>
                </div>
				                
                <div class="buttons clearfix">
                  <div class="pull-right">
                    <button type="button" id="button-comment" data-loading-text="Loading..." class="btn btn-primary">Continue</button>
                  </div>
                </div>
                              </form>
            			
	<div id="blog-wrapper" class="blog-wrapper epost_related">
					  
		   
			<div class="comman_title text-center">
				<h2>Related Posts</h2>
			</div> 
		    <div id="related_post" class="owl-carousel" style="opacity: 1;">
		  		   
				<div class="update_post item col-sm-12">
					<div class="blog-inner-section">
							<div class="blog-images-section">
							<div class="video-image">
								<a href="<?php echo $mainurl;?>/product-header"><img src="<?php echo $baseurl;?>image/EB2-380x300.jpg" alt="Bike News Roundup: The Future of Mobility" title="Bike News Roundup: The Future of Mobility" class="img-responsive" /></a>
															</div>
							<!--<div class="date">
																<a href=""><p>23</p><span>Apr</span></a>
															</div> -->
	</div>
		<div class="blog-text-section">					
				<h3><a href="<?php echo $mainurl;?>/product-header">Bike News Roundup: The Future of Mobility</a></h3>
							<div class="auther_wrp">
										<a href="" class="auther_wrapper"><span>Post By</span> Admin</a>
										<span><a href="">23 Apr,2019</a></span>
				</div>	
							
								
						<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomi..</p>
		<div class="readmore_button pull-left">
							<a href="<?php echo $mainurl;?>/product-header" class="base-button">Read More</a>
																		
								</div>	
								
									<div class="clear"></div>
								</div>
					  </div> 
				</div> 
			
				   
				<div class="update_post item col-sm-12">
					<div class="blog-inner-section">
							<div class="blog-images-section">
							<div class="video-image">
						<a href="<?php echo $mainurl;?>/product-header"><img src="<?php echo $baseurl;?>/image/EB1-380x300.jpg" alt="Bike News Roundup: The Future of Mobility" title="Bike News Roundup: The Future of Mobility" class="img-responsive" /></a>
			</div>
							<!--<div class="date">
																<a href=""><p>23</p><span>Apr</span></a>
															</div> -->
							</div>
	<div class="blog-text-section">
						<h3><a href="<?php echo $mainurl;?>/product-header">Bike News Roundup: The Future of Mobility</a></h3>
														
							
				<div class="auther_wrp">
								<a href="" class="auther_wrapper"><span>Post By</span> Ashley Wick</a> |
									<span><a href="">23 Apr,2019</a></span>
					</div>	
							
						<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomi..</p>
	<div class="readmore_button pull-left">
							<a href="<?php echo $mainurl;?>/product-header" class="base-button">Read More</a>
																		
								</div>	
								
									<div class="clear"></div>
								</div>
					  </div> 
				</div> 
			
				   
				<div class="update_post item col-sm-12">
					<div class="blog-inner-section">
							<div class="blog-images-section">
							<div class="video-image">
										<a href="<?php echo $mainurl;?>/product-header
										"><img src="<?php echo $baseurl;?>image/EB3-380x300.jpg" alt="Bike News Roundup: The Future of Mobility" title="Bike News Roundup: The Future of Mobility" class="img-responsive" /></a>
															</div>
							<!--<div class="date">
																<a href=""><p>23</p><span>Apr</span></a>
															</div> -->
					</div>
							<div class="blog-text-section">
                               <h3><a href="<?php echo $mainurl;?>/product-header">Bike News Roundup: The Future of Mobility</a></h3>
							<div class="auther_wrp">
								<a href="" class="auther_wrapper"><span>Post By</span> Ashley Wick</a> |
							<span><a href="">23 Apr,2019</a></span>
					</div>	
						       <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomi..</p>
									<div class="readmore_button pull-left">
										<a href="<?php echo $mainurl;?>/Blog" class="base-button">Read More</a>
																		
								</div>	
								
									<div class="clear"></div>
								</div>
					  </div> 
				</div> 
			
				   
				<div class="update_post item col-sm-12">
					<div class="blog-inner-section">
							<div class="blog-images-section">
							<div class="video-image">
									<a href="<?php echo $mainurl;?>/product-header"><img src="<?php echo $baseurl;?>image/EB4-380x300.jpg" alt="Bike News Roundup: The Future of Mobility" title="Bike News Roundup: The Future of Mobility" class="img-responsive" /></a>
															</div>
							<!--<div class="date">
																<a href=""><p>23</p><span>Apr</span></a>
															</div> -->
							</div>
							<div class="blog-text-section">
							   <h3><a href="<?php echo $mainurl;?>/product-header">Bike News Roundup: The Future of Mobility</a></h3>
														
							
							<div class="auther_wrp">
								<a href="" class="auther_wrapper"><span>Post By</span> Admin</a> |
										<span><a href="">23 Apr,2019</a></span>
				</div>	
							<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomi..</p>
				<div class="readmore_button pull-left">
							<a href="<?php echo $mainurl;?>/product-header" class="base-button">Read More</a>
		</div>		
									<div class="clear"></div>
								</div>
					  </div> 
				</div> 
			
				</div> 
				</div>
			
				<div class="owl-controls clickable" style="display: none;"><div class="owl-buttons"><div class="owl-prev"><i class="fa fa-angle-left fa-5x"></i></div><div class="owl-next"><i class="fa fa-angle-right fa-5x"></i></div></div></div></div> 
				</div>
		<div class="product_wrapper">
				</div>
		
		
		</div>
    </div>
</div></div>
<!-----image script------>
<script type="text/javascript">
 $('.quickviewopen').magnificPopup({
	disableOn: 700,
	type: 'iframe',
	mainClass: 'mfp-fade',
	removalDelay: 160,
	preloader: true,
	fixedContentPos: true
});

	$(document).ready(function(){
	$('#related_prodcts_blog').owlCarousel({	
		items: 3,
		itemsDesktop:[1199,3],
		itemsDesktopSmall:[992,3],
		itemsTablet:[768,2],
		itemsMobile:[450,1],
		autoPlay: 6000,
		pagination: false,
		navigation: true,
		navigationText: ['<i class="fa fa-angle-left fa-5x"></i>', '<i class="fa fa-angle-right fa-5x"></i>']
	});
}); 


$(document).ready(function(){
	$('#related_post').owlCarousel({	
		items: 2,
		itemsDesktop:[1199,2],
		itemsDesktopSmall:[992,2],
		itemsTablet:[768,2],
		itemsMobile:[450,1],
		autoPlay: 6000,
		pagination: false,
		navigation: true,
		navigationText: ['<i class="fa fa-angle-left fa-5x"></i>', '<i class="fa fa-angle-right fa-5x"></i>']
	});
}); 
</script>
<script>
	
</script>

<script>

</script>
<script type="text/javascript">
$('#comment').delegate('.pagination a', 'click', function(e) {
    e.preventDefault();

    $('#comment').fadeOut('slow');

    $('#comment').load(this.href);

    $('#comment').fadeIn('slow');
});

$('#comment').load('index.php?route=extension/eblog/epost/comment&epost_id=1');

$('#button-comment').on('click', function() {
	$.ajax({
		url: 'index.php?route=extension/eblog/epost/write&epost_id=1',
		type: 'post',
		dataType: 'json',
		data: $("#form-comment").serialize(),
		beforeSend: function() {
			$('#button-comment').button('loading');
		},
		complete: function() {
			$('#button-comment').button('reset');
		},
		success: function(json) {
			$('.alert-dismissible').remove();

			if (json['error']) {
				$('#comment').after('<div class="alert alert-danger alert-dismissible"><i class="fa fa-exclamation-circle"></i> ' + json['error'] + '</div>');
			}

			if (json['success']) {
				$('#comment').after('<div class="alert alert-success alert-dismissible"><i class="fa fa-check-circle"></i> ' + json['success'] + '</div>');

				$('input[name=\'name\']').val('');
				$('textarea[name=\'text\']').val('');
				$('input[name=\'rating\']:checked').prop('checked', false);
			}
		}
	});
});

$(document).ready(function() {
	$('.openthumbs').magnificPopup({
		type:'image',
		delegate: 'a',
		gallery: {
			enabled: true
		}
	});
});
//--></script>
<!--------/ end --->
<!-------news letter style and script----->
<style>
	#newsletterModal .modal-body{
		background-image:url('');
	}
	
</style>
<div id="newsletterModal" class="modal fade newsletter_popup" role="dialog"  aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content swing">
			<button type="button" class="close closepopup" data-dismiss="modal"><img src="<?php echo $baseurl;?>image/close_news.png" alt="close_news" title="close_news"/></button>

			<div class="modal-body">
							
				<h3>Sign Up For Our Newsletter:</h3>
<p>Get All The Latest Information On Events,Sales And Offers.<br> Sign Up For Newsletter Today</p>
				
				<form class="subsribe">
					<div class="successmsg"></div>
											<div class="form-group required">
														  <input type="text" id="input-newsletter-email" class="form-control" placeholder="Enter Your Email Address here" value="" name="email"/>
							  <div class="input-group">
							  <span class="">
								<a class="btn btn-primary button-subsribe">Subscribe</a>
							  </span>
							</div>
							<!-- /input-group -->
						</div>
				</form>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
$('#newsletterModal .button-subsribe').on('click', function(){
	$.ajax({
		url: 'index.php?route=extension/awesomenewsletter_popup/addsubscribe',
		type: 'post',
		data: $('#newsletterModal .subsribe input[type=\'text\']'),
		dataType: 'json',
		beforeSend: function(){
			$('#newsletterModal .button-subsribe').button('loading');
		},
		complete: function(){
			$('#newsletterModal .button-subsribe').button('reset');
		},
		success: function(json){
			$('.alert, .text-danger').remove();
			$('.form-group').removeClass('has-error');
			$('#newsletterModal .successmsg').html('');
			
			if(json['error']) {
				for (i in json['error']) {
					var element = $('#newsletterModal #input-newsletter-' + i.replace('_', '-'));

					if ($(element).parent().hasClass('input-group')){
						$(element).parent().after('<div class="text-danger">' + json['error'][i] + '</div>');
					} else {
						$(element).after('<div class="text-danger">' + json['error'][i] + '</div>');
					}
				}
				
				$('.text-danger').parent().addClass('has-error');
			}
			
			if(json['success']) {
				$('#newsletterModal .successmsg').html('<div class="alert alert-success">' + json['success'] + '<button type="button" class="close" data-dismiss="alert">&times;</button></div>');
				
				$('#newsletterModal .subsribe input[type=\'text\']').val('');
			}
			
			if(json['warring']) {
				$('#newsletterModal .successmsg').html('<div class="alert alert-danger">' + json['warring'] + '<button type="button" class="close" data-dismiss="alert">&times;</button></div>');
			}
		}
	});
});
</script>
<script type="text/javascript">
$(document).ready(function () {
	var time = parseInt(10*1000);
	setTimeout(function(){
		$('#newsletterModal').modal('show')  
	}, time); 
});
</script>
