<?php
if(!isset($_SESSION["aid"]))
{
    echo "<script>
    window.location='./';
    </script>";
    
}

?>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Add or Change Customer Logo</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Add Logo here</li>
            </ol>
            <div class="row">
                <div class="col-md-8">
                    <div class="card text-white mb-4">
                        <div class="card-body">Add Logo Form</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            
                        <form method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <input type="file" name="img" placeholder="Enter logo" class="form-control" required>

                            </div>

                            <div class="form-group">
                                <select  name="status" placeholder="status of image" class="form-control" required>

                                <option value="">-Select status-</option>
                                <option value="0">Off</option>
                                <option value="1">On</option>
                                
                                </select>
                            </div>

                            <div class="form-group">
                                <input type="date" name="addeddate" placeholder="Select Date" class="form-control" required>

                            </div>

                            <div class="form-group">
                                <input type="submit" name="addlogo" class="btn btn-lg btn-primary" value="AddLogo">

                            </div>
                        </form>





                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
                


                <div class="col-md-12">
                    <div class="card text-white mb-4">


                        <div class="card-body">Manage All Logo</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                        

                    <div class="table-responsive" style="color:black">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Photo</th>
                                    <th>Added Date</th>
                                    <th>Action</th>
                                   
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                <th>Id</th>
                                <th>Photo</th>
                                <th>Added Date</th>
                                <th>Action</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <?php
                                foreach($logo as $logo1)

                                {
                                    ?>
                                <tr>
                                    <td><?php echo $logo1["logoid"];?></td>
                                    <td><img src="<?php echo $logo1["photo"];?>" width="85px" height="85px"></td>
                                    <td><?php echo $logo1["added_date"];?></td>
                                    <td><a href="" class="btn btn-danger"><span class="fa fa-trash"></span> Delete</a></td>
                                
                                </tr>
                               
                                <?php
                                }

                                ?>
                            </tbody>
                        </table>
    
                    </div>
                </div>
            </div>



                </div>
            </div>
        </div>
    </main>












                    </div>
                </div>
            </div>
        </div>
    </main>

    