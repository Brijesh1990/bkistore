<?php
class adminmodel
{
 public $connection="";   
 public function __construct()

 {
     session_start();
     try {



         $this->connection=new mysqli("localhost", "root", "", "bycycle");


        
        // $this->connection=new mysqli("sql204.byethost33.com","b33_28063524","b12345","b33_28063524_bycycle");
     
     
        }
     catch(Exception $e)
     {
         die(mysqli_error($this->connection,$e));
     }
 }

 //create a member function for admin Login
 public function adminlogin($table,$em,$pass)
 {
  
    $select="select * from $table where email='$em' and password='$pass'";
    $query=mysqli_query($this->connection,$select);
    $result=mysqli_fetch_array($query);
    $no=mysqli_num_rows($query);
    if($no>0)
    {
        $_SESSION["aid"]=$result["aid"];
        $_SESSION["em"]=$result["email"];
        return $query;
         
    }

    else
    {
        return false;
    }
 }

 //create a meber function for insert all data


 public function insalldata($table,$data)
 {

     $column=array_keys($data);
     $column1=implode(",",$column);

     $value=array_values($data);
     $value1=implode("','",$value);
     
     $insert="insert into $table($column1) values('$value1')";
     $query=mysqli_query($this->connection,$insert);
     return $query;

 }

 //create a member function for select alldata

 public function selectalldata($table) 

    {
       $select="select * from $table";
       $query=mysqli_query($this->connection,$select);
       while($result=mysqli_fetch_array($query))

       {
          
        $arr[]=$result;
       
    
    }

       return $arr;

    }

//create a member function for select alldata

 public function selectjoinalldata($table,$table1,$where) 

 {
    $select="select * from $table join $table1 on $where";
    $query=mysqli_query($this->connection,$select);
    while($result=mysqli_fetch_array($query))

    {
       
     $arr[]=$result;
    
 
 }

    return $arr;

 }

 //create a member function for select alldata

 public function selectjoinalldata1($table,$table1,$table2,$where,$where1) 

 {
    $select="select * from $table join $table1 on $where join $table2 on $where1";
    $query=mysqli_query($this->connection,$select);
    while($result=mysqli_fetch_array($query))

    {
       
     $arr[]=$result;
    
 
 }

    return $arr;

 }

//create a member function for deldata
public function deldata($table,$id)
{

    $column=array_keys($id);
    $field=implode(",",$column);

    $value=array_values($id);
    $value1=implode("','",$value);

    $del="delete from $table where $field='$value1'";
    $query=mysqli_query($this->connection,$del);
    return $query;

}

//create a member function for Manage all Customers in Admin
public function managecustomers($table,$table1,$table2,$where,$where1) 

{
    
    // select * from $table join $table1 on $table.sid=$table1.sid join $table2 on $table.ctid=$table2.ctid;
    
    $select="select * from $table join $table1 on $where join $table2 on $where1";
    $query=mysqli_query($this->connection,$select);
    while($result=mysqli_fetch_array($query))
    {
        
    $arr[]=$result;

    }

    return $arr;

}
//create a member function for read all data

public function readalldata($table,$table1,$column,$id,$where) 

{
$select="select * from $table join $table1 on $where where $column='$id'";
   $query=mysqli_query($this->connection,$select);
   while($result=mysqli_fetch_array($query))

   {
      
    $arr[]=$result;
   

}

   return $arr;

}

//update data create a member function

public function updsubcategory($table,$catnm,$subcatnm,$addate,$column,$id)
{
     $upd="update $table set  catid='$catnm',subcatname='$subcatnm',addedsubcategory_date='$addate'  where $column='$id'"; 
    $query=mysqli_query($this->connection,$upd);
    return $query;
}

//create a member function for count data
public function countdata($table,$column)

{
   $sel="select count($column) as total from $table";
   $query=mysqli_query($this->connection,$sel);
   while($result=mysqli_fetch_array($query))
   {
       $arr[]=$result;
   }

   return $arr;


}

 //create meber function for logout admin
 public function logout()
 {

      unset($_SESSION["aid"]);
      
      unset($_SESSION["em"]);

      session_destroy();

      return true;


 }

}

?>