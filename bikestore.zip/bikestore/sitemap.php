
<!-----start first-section---> 
<div class="main_breadcrumb">
      <div class="container-fluid">
           <div class="row">
               <ul class="breadcrumb">
                     <h3>site map</h3>
                    <li><a href="<?php echo $mainurl;?>/">Home</a></li>
                    <li><a href="sitemap.html">site map</a></li>
                </ul>
           </div>
      </div>                
</div>
 <!---- second section--->
<div class="main_padding">
<div id="information-sitemap" class="container">
  <div class="row">
                <div id="content" class="col-sm-12">
      <h1>Site Map</h1>
      <div class="row">
        <div class="col-sm-6">
          <ul>
                        <li><a href="product-header.htmlacing Bicycles"></a>
                            <ul>
                                <li><a href="<?php echo $mainurl;?>product-header">Racing Bicycle Thin Tyre</a>
                                  </li>
                                <li><a href="<?php echo $mainurl;?>product-header">Racing Bicycle Alminium Frame</a>
                                  </li>
                                <li><a href="<?php echo $mainurl;?>product-header">Racing Bicycle Down Frame</a>
                                  </li>
                                <li><a href="<?php echo $mainurl;?>product-header">Racing Bicycle Magnesium</a>
                                  </li>
                                <li><a href="<?php echo $mainurl;?>product-header">Racing Bicycle Alminium Break</a>
                                  </li>
                              </ul>
                          </li>
                        <li><a href="product-header.htmlaby Try Cycles"></a>
                            <ul>
                                <li><a href="<?php echo $mainurl;?>product-header">Tri Cycle With Push Handle</a>
                                  </li>
                                <li><a href="<?php echo $mainurl;?>product-header">Tri Cycle With Back Basket</a>
                                  </li>
                                <li><a href="<?php echo $mainurl;?>product-header">Tri Cycle With Basket</a>
                                    <ul>
                                        <li><a href="product-header.html_65">Tri Cycle With Red Color</a></li>
                                      </ul>
                                  </li>
                                <li><a href="<?php echo $mainurl;?>product-header">Tri Cycle With Plastic Tyre</a>
                                  </li>
                                <li><a href="<?php echo $mainurl;?>product-header">Tri Cycle With Rubber Tyre</a>
                                  </li>
                              </ul>
                          </li>
                        <li><a href="product-header.html"at Bikes></a>
                            <ul>
                                <li><a href="<?php echo $mainurl;?>product-header">Aliminium Frame Body</a>
                                  </li>
                                <li><a href="<?php echo $mainurl;?>product-header">Fat Bike Front Disc</a>
                                  </li>
                                <li><a href="<?php echo $mainurl;?>product-header">Iron Frame Body</a>
                                  </li>
                                <li><a href="<?php echo $mainurl;?>product-header">Fat Bike Back Disc</a>
                                  </li>
                                <li><a href="<?php echo $mainurl;?>product-header">Fat Bike Combo Disc</a>
                                  </li>
                              </ul>
                          </li>
                        <li><a href="product-header.htmlybrid Bicycles"></a>
                            <ul>
                                <li><a href="<?php echo $mainurl;?>product-header">Hybrid Powerfull Breaks</a>
                                  </li>
                                <li><a href="<?php echo $mainurl;?>product-header">Hybrid Bicycle With Disc</a>
                                  </li>
                                <li><a href="<?php echo $mainurl;?>product-header">Hybrid Bicycle Without Disc</a>
                                  </li>
                                <li><a href="<?php echo $mainurl;?>product-header">Hybrid Bicycle With Gear</a>
                                  </li>
                                <li><a href="<?php echo $mainurl;?>product-header">Hybrid Bicycle Without Gear</a>
                                  </li>
                              </ul>
                          </li>
                        <li><a href="product-header.htmlrack Bicycles"></a>
                            <ul>
                                <li><a href="<?php echo $mainurl;?>product-header">Track Bicycle Heavy Body</a>
                                  </li>
                                <li><a href="<?php echo $mainurl;?>product-header">Track Bicycle With Adustable Seat</a>
                                  </li>
                                <li><a href="<?php echo $mainurl;?>product-header">Track Bicycle Sports Look</a>
                                  </li>
                                <li><a href="<?php echo $mainurl;?>product-header">Track Bicycle With Adustable Handle</a>
                                  </li>
                                <li><a href="<?php echo $mainurl;?>product-header">Track Bicycle With Thick Tyre</a>
                                  </li>
                              </ul>
                          </li>
                        <li><a href="product-header.htmlotorized Bicycles"></a>
                            <ul>
                                <li><a href="<?php echo $mainurl;?>product-header">Motorized Bicycle 4 Batteries</a>
                                  </li>
                                <li><a href="<?php echo $mainurl;?>product-header">Motorized Bicycle 6 Batteries</a>
                                  </li>
                                <li><a href="<?php echo $mainurl;?>product-header">Motorized Bicycle With Accessories</a>
                                  </li>
                                <li><a href="<?php echo $mainurl;?>product-header">Motorized Bicycle Without Paddle</a>
                                  </li>
                                <li><a href="<?php echo $mainurl;?>product-header">Motorized Bicycle With Paddle</a>
                                  </li>
                              </ul>
                          </li>
                      </ul>
        </div>
        <div class="col-sm-6">
          <ul>
            <li><a href="<?php echo $mainurl;?>/brand">Special Offers</a></li>
            <li><a href="<?php echo $mainurl;?>/">My Account</a>
              <ul>
                <li><a href="<?php echo $mainurl;?>/login">Account Information</a></li>
                <li><a href="<?php echo $mainurl;?>/login">Password</a></li>
                <li><a href="<?php echo $mainurl;?>/Contact">Address Book</a></li>
                <li><a href="#;">Order History</a></li>
                <li><a href="#;">Downloads</a></li>
              </ul>
            </li>
            <li><a href="<?php echo $mainurl;?>product-header">Shopping Cart</a></li>
            <li><a href="checkout.html">Checkout</a></li>
            <li><a href="<?php echo $mainurl;?>product-header">Search</a></li>

        <!--eblog START-->
        <li>Blogs
          <ul>
                        <li><a href="<?php echo $mainurl;?>product-header">Alminium Bicycle</a>
                          </li>
                        <li><a href="<?php echo $mainurl;?>product-header">Bicycle With Combo Disc </a>
                          </li>
                        <li><a href="p<?php echo $mainurl;?>product-header">Sporty Bicycle</a>
                          </li>
                        <li><a href="<?php echo $mainurl;?>product-header">Super Slim Thin Tyre Bicycle</a>
                          </li>
                        <li><a href="<?php echo $mainurl;?>product-header">Premium MTB Suspension Bicycle</a>
                          </li>
                      </ul>
        </li>
      <!--eblog END-->
      
            <li>Information
              <ul>
                                <li><a href="<?php echo $mainurl;?>/about">About Us</a></li>
                                <li><a href="#;">Delivery Information</a></li>
                                <li><a href="#;">Privacy Policy</a></li>
                                <li><a href="#">Terms &amp; Conditions</a></li>
                                <li><a href="<?php echo  $mainurl; ?>contact">Contact Us</a></li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
      </div>
    </div>
</div></div>
