
<!---------catagory-banner-------->
<div class="main_breadcrumb">
	<div class="container-fluid">
		<div class="row">
		 <ul class="breadcrumb">
		   <h3>Latest Blog</h3>
						<li><a href="<?php echo $mainurl;?>/">Home</a></li>
						<li><a href="<?php echo $mainurl;?>/Blog">Blog</a></li>
					  </ul>
		</div>
	</div>
</div><!------catagry banner end------>

<div id="blog-wrapper" class="blog-wrapper inner-blog-wrapper">
<div class="container-fluid">
  <div class="row eblog" ><aside id="column-left" class="col-sm-3 hidden-xs">
    <div class="search popular_posts">
	<h4 class="">Latest Blog</h4>
	<div id="blog_sidebar0" class="owl-carousel">
				<div class="">
						<div class="popular_posts_section">
			 				<div class="popular_posts_images">
					<a href="#"><img alt="Bike News Roundup: T.." title="Bike News Roundup: T.." class="img-responsive" src="<?php echo $baseurl;?>image/EB2.jpg"/></a>
				</div>
			 				<div class="popular_posts_text">
					<h5><a href="#">Bike News Roundup: T..</a></h5>
					<Span>By Admin</Span>
					<span>						<a href="#">23 Apr,2019</a>
						</span>
				</div>
			</div>
						<div class="popular_posts_section">
			 				<div class="popular_posts_images">
					<a href="#"><img alt="Bike News Roundup: T.." title="Bike News Roundup: T.." class="img-responsive" src="<?php echo $baseurl;?>image/EB1.jpg"/></a>
				</div>
			 				<div class="popular_posts_text">
					<h5><a href="#">Bike News Roundup: T..</a></h5>
					<Span>By Ashley Wick</Span>
					<span>						<a href="#">23 Apr,2019</a>
						</span>
				</div>
			</div>
						<div class="popular_posts_section">
			 				<div class="popular_posts_images">
					<a href="#"><img alt="Bike News Roundup: T.." title="Bike News Roundup: T.." class="img-responsive" src="<?php echo $baseurl;?>image/EB3.jpg"/></a>
				</div>
			 				<div class="popular_posts_text">
					<h5><a href="#">Bike News Roundup: T..</a></h5>
					<Span>By Ashley Wick</Span>
					<span>						<a href="#">23 Apr,2019</a>
						</span>
				</div>
			</div>
					</div>
				<div class="">
						<div class="popular_posts_section">
			 				<div class="popular_posts_images">
					<a href="#"><img alt="Bike News Roundup: T.." title="Bike News Roundup: T.." class="img-responsive" src="<?php echo $baseurl;?>image/EB4.jpg"/></a>
				</div>
			 				<div class="popular_posts_text">
					<h5><a href="#">Bike News Roundup: T..</a></h5>
					<Span>By Admin</Span>
					<span>						<a href="#">23 Apr,2019</a>
						</span>
				</div>
			</div>
					</div>
			</div>
</div>

  <script>
$(document).ready(function(){
	$('#blog_sidebar0').owlCarousel({
		items: 1,
		itemsDesktop:[1199,1],
		itemsDesktopSmall:[992,1],
		itemsTablet:[768,1],
		itemsMobile:[450,1],
		pagination: false,
		navigation: true,
		navigationText: ['<i class="fa fa-angle-left fa-5x"></i>', '<i class="fa fa-angle-right fa-5x"></i>']
	});
});   
</script>
    <div class="search popular_posts">
	<h4 class="">Popular Posts</h4>
	<div id="blog_sidebar1" class="owl-carousel">
				<div class="">
						<div class="popular_posts_section">
			 				<div class="popular_posts_images">
					<a href="#"><img alt="Bike News Roundup: T.." title="Bike News Roundup: T.." class="img-responsive" src="<?php echo $baseurl;?>image/EB2.jpg"/></a>
				</div>
			 				<div class="popular_posts_text">
					<h5><a href="#">Bike News Roundup: T..</a></h5>
					<Span>By Admin</Span>
					<span>						<a href="#">23 Apr,2019</a>
						</span>
				</div>
			</div>
						<div class="popular_posts_section">
			 				<div class="popular_posts_images">
					<a href="#"><img alt="Bike News Roundup: T.." title="Bike News Roundup: T.." class="img-responsive" src="<?php echo $baseurl;?>image/EB3.jpg"/></a>
				</div>
			 				<div class="popular_posts_text">
					<h5><a href="#">Bike News Roundup: T..</a></h5>
					<Span>By Ashley Wick</Span>
					<span>						<a href="#">23 Apr,2019</a>
						</span>
				</div>
			</div>
						<div class="popular_posts_section">
			 				<div class="popular_posts_images">
					<a href="#"><img alt="Bike News Roundup: T.." title="Bike News Roundup: T.." class="img-responsive" src="<?php echo $baseurl;?>image/EB1.jpg"/></a>
				</div>
			 				<div class="popular_posts_text">
					<h5><a href="#">Bike News Roundup: T..</a></h5>
					<Span>By Ashley Wick</Span>
					<span>						<a href="#">23 Apr,2019</a>
						</span>
				</div>
			</div>
					</div>
			</div>
</div>

  <script>
$(document).ready(function(){
	$('#blog_sidebar1').owlCarousel({
		items: 1,
		itemsDesktop:[1199,1],
		itemsDesktopSmall:[992,1],
		itemsTablet:[768,1],
		itemsMobile:[450,1],
		pagination: false,
		navigation: true,
		navigationText: ['<i class="fa fa-angle-left fa-5x"></i>', '<i class="fa fa-angle-right fa-5x"></i>']
	});
});   
</script>
  </aside>

                <div id="content" class="col-sm-9">
      <h1>Latest Blog</h1> 
      
	  		<div class="row search_blog">
				  <div class="update_post col-sm-4">
			<div class="blog-inner-section">
						<div class="blog-images-section">
						<div class="video-image">
														<a href="#"><img src="<?php echo $baseurl;?>image/EB1.jpg" alt="Bike News Roundup: The Future of Mobility" title="Bike News Roundup: The Future of Mobility" class="img-responsive" /></a>
													</div>
						
						</div>
						<div class="blog-text-section">
			
						<div class="auther_wrp">
							<h3><a href="#">Bike News Roundup: The Future of Mobility</a></h3>
							
															<a href="#" class="auther_wrapper">Post By <span>Admin</span>
															</a> |
																					<span><a href="">23 Apr,2019</a></span>
													</div>	
													
														
														<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomi..</p>
														<div class="readmore_button pull-left">
																<a href="<?php echo $mainurl;?>/latast-blog2" class="base-button">Read More</a>
																
							</div>	
							<!-- <div class="views_wrp pull-right">		
																			<div class="  ">
										  <ul class="list-inline blogcomments">
																						<li><i class="fa fa-eye"></i> <span>80</span></li>
																						
																						<li><i class="fa fa-comments-o"></i> <span>0</span></li>
																					  </ul>
										</div>
																	</div> --->
								<div class="clear"></div>
							</div>
				  </div> 
		  </div>
				  <div class="update_post col-sm-4">
			<div class="blog-inner-section">
						<div class="blog-images-section">
						<div class="video-image">
														<a href="#"><img src="<?php echo $baseurl;?>image/EB4.jpg" alt="Bike News Roundup: The Future of Mobility" title="Bike News Roundup: The Future of Mobility" class="img-responsive" /></a>
													</div>
						<!--<div class="date">
														<a href=""><p>23</p><span>Apr</span></a>
													</div> -->
						</div>
						<div class="blog-text-section">
			
						<div class="auther_wrp">
							<h3><a href="#">Bike News Roundup: The Future of Mobility</a></h3>
							
															<a href="#" class="auther_wrapper">Post By <span>Admin</span><!-- Admin --></a> |
																					<span><a href="">23 Apr,2019</a></span>
													</div>	
													
														
														<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomi..</p>
														<div class="readmore_button pull-left">
																<a href="<?php echo $mainurl;?>/latast-blog2" class="base-button">Read More</a>
																
							</div>	
							<!-- <div class="views_wrp pull-right">		
																			<div class="  ">
										  <ul class="list-inline blogcomments">
																						<li><i class="fa fa-eye"></i> <span>78</span></li>
																						
																						<li><i class="fa fa-comments-o"></i> <span>0</span></li>
																					  </ul>
										</div>
																	</div> --->
								<div class="clear"></div>
							</div>
				  </div> 
		  </div>
				  <div class="update_post col-sm-4">
			<div class="blog-inner-section">
						<div class="blog-images-section">
						<div class="video-image">
														<a href="#"><img src="<?php echo $baseurl;?>image/EB3.jpg" alt="Bike News Roundup: The Future of Mobility" title="Bike News Roundup: The Future of Mobility" class="img-responsive" /></a>
													</div>
						<!--<div class="date">
														<a href=""><p>23</p><span>Apr</span></a>
													</div> -->
						</div>
						<div class="blog-text-section">
			
						<div class="auther_wrp">
							<h3><a href="#">Bike News Roundup: The Future of Mobility</a></h3>
							
															<a href="#" class="auther_wrapper">Post By <span>Admin</span>
															</a> 
																					<span><a href="">23 Apr,2019</a></span>
													</div>	
													
														
														<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomi..</p>
														<div class="readmore_button pull-left">
																<a href="<?php echo $mainurl;?>/latast-blog2" class="base-button">Read More</a>
																
							</div>	
							
								<div class="clear"></div>
							</div>
				  </div> 
		  </div>
				  <div class="update_post col-sm-4">
			<div class="blog-inner-section">
						<div class="blog-images-section">
						<div class="video-image">
														<a href="#"><img src="<?php echo $baseurl;?>image/EB2.jpg" alt="Bike News Roundup: The Future of Mobility" title="Bike News Roundup: The Future of Mobility" class="img-responsive" /></a>
													</div>
						<!--<div class="date">
														<a href=""><p>23</p><span>Apr</span></a>
													</div> -->
						</div>
						<div class="blog-text-section">
			
						<div class="auther_wrp">
							<h3><a href="#">Bike News Roundup: The Future of Mobility</a></h3>
							
															<a href="#" class="auther_wrapper">Post By <span>Admin</span><!-- Admin --></a> |
																					<span><a href="">23 Apr,2019</a></span>
													</div>	
													
														
														<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomi..</p>
														<div class="readmore_button pull-left">
																<a href="<?php echo $mainurl;?>/latast-blog2" class="base-button">Read More</a>
																
							</div>	

								<div class="clear"></div>
							</div>
				  </div> 
		  </div>
				</div>
		<div class="row">
			<div class="col-sm-6 text-left"></div>
			<div class="col-sm-6 text-right">Showing 1 to 4 of 4 (1 Pages)</div>
		</div>
			  </div>
    </div>
</div></div>