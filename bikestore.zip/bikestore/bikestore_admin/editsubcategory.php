<?php
if(!isset($_SESSION["aid"]))
{
    echo "<script>
    window.location='./';
    </script>";
    
}

?>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Edit Sub Category</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Edit Sub Category</li>
            </ol>
            <div class="row">
                <div class="col-md-8">
                    <div class="card text-white mb-4">
                        <div class="card-body">Edit Subcategory Here</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            
                        <form method="post">
                            
                        <div class="form-group">

                               <label class="text-success">Edit Category :</label> <select name="catname" placeholder="Enter  Category Name" class="form-control" required>
                                
                                <option value="">-select Category-</option>

                                <?php 
                                
                                foreach ($catnm as $catnm1) {
                                    if ($catnm1["catid"]==$shwsubcat[0]["catid"]) {
                                        ?>
                                <option value="<?php echo $shwsubcat[0]["catid"]; ?>" selected="selected"><?php echo $shwsubcat[0]["catname"]; ?></option>



                                <?php
                                    } else {
                                        ?>

<option value="<?php echo $catnm1["catid"]; ?>"><?php echo $catnm1["catname"]; ?></option>
                           <?php
                                    }
                                }
                                 ?>
                                </select>

                            </div>
                            
                            <div class="form-group">
                            <label class="text-success">  Edit Subcategory Name :</label><input type="text" name="subcatname" value="<?php echo $shwsubcat[0]["subcatname"];?>" placeholder="Enter Sub Category Name" class="form-control" required>

                            </div>

                            <div class="form-group">
                            <label class="text-success">Edit Added Date :</label><input type="date" name="addeddate" value="<?php echo $shwsubcat[0]["addedsubcategory_date"];?>" placeholder="Select Date" class="form-control" required>

                            </div>

                            <div class="form-group">
                        

                            <div class="form-group">
                                <input type="submit" name="updsubcat" class="btn btn-lg btn-primary" value="UpdateSubCategory">

                            </div>



                            </div>


                        </form>





                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
                

                    </div>
                </div>
            </div>
        </div>
    </main>

    