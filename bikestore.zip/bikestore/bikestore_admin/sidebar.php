
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">MVC Shop</div>
                        <a class="nav-link" href="<?php echo $mainurl;?>admin-dashboard">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Dashboard
                        </a>
                        <a class="nav-link" href="<?php echo $mainurl;?>admin-managecustomer">
                            <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                            Manage Customers
                        </a>
                        <a class="nav-link" href="<?php echo $mainurl; ?>AddLogo">
                            <div class="sb-nav-link-icon"><i class="fas fa-image"></i></div>
                            Manage Logo
                        </a>
                        
                        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                            <div class="sb-nav-link-icon"><i class="fa fa-shopping-cart"></i></div>
                            Add Category
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">
                                <a class="nav-link" href="<?php echo $mainurl;?>admin-addcategory">Add Category</a>
                                <a class="nav-link" href="<?php echo $mainurl;?>admin-managecategory">Manage Category</a>
                            </nav>
                        </div>

                    
                        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLayouts1" aria-expanded="false" aria-controls="collapseLayouts">
                            <div class="sb-nav-link-icon"><i class="fa fa-shopping-cart"></i></div>
                            Add SubCategory
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapseLayouts1" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">
                                <a class="nav-link" href="<?php echo $mainurl;?>admin-addsubcategory">Add SubCategory</a>
                                <a class="nav-link" href="<?php echo $mainurl;?>admin-managesubcategory">Manage SubCategory</a>
                            </nav>
                        </div>

                        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLayouts2" aria-expanded="false" aria-controls="collapseLayouts">
                            <div class="sb-nav-link-icon"><i class="fa fa-shopping-cart"></i></div>
                            Add Products
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapseLayouts2" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">
                                <a class="nav-link" href="<?php echo $mainurl; ?>admin-addproduct">Add Products</a>
                                <a class="nav-link" href="<?php echo $mainurl; ?>admin-manageproduct">Manage Products</a>
                            </nav>
                        </div>

                    
                        <a class="nav-link" href="charts.html">
                            <div class="sb-nav-link-icon"><i class="fa fa-map-marker"></i></div>
                            Add State
                        </a> 
                    

                        <a class="nav-link" href="charts.html">
                            <div class="sb-nav-link-icon"><i class="fa fa-map-marker"></i></div>
                            Add City
                        </a>                       
                        
                        <a class="nav-link" href="charts.html">
                            <div class="sb-nav-link-icon"><i class="fas fa-truck"></i></div>
                            Manage Orders &nbsp; <span class="badge badge-lg bg-danger">0</span>
                        </a>
                        
                        <a class="nav-link" href="charts.html">
                            <div class="sb-nav-link-icon"><i class="fa fa-users"></i></div>
                            Manage Feedback &nbsp; <span class="badge badge-lg bg-danger">0</span>
                        </a>
                        <a class="nav-link" href="tables.html">
                            <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                            Manage Contacts &nbsp; <span class="badge badge-lg bg-danger">0</span>
                        </a>
                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="small">Logged in as:</div>
                    Start Bootstrap
                </div>
            </nav>
        </div>
