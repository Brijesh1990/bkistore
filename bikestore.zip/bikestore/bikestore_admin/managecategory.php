<?php
if(!isset($_SESSION["aid"]))
{
    echo "<script>
    window.location='./';
    </script>";
    
}

?>
<style>
tr:nth-child(even)
{
    background-color: lightblue;

}

tr:nth-child(odd)
{
    background-color:lighgray;

}


</style>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Manage Category</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Manage Category</li>
            </ol>
            <div class="row">
                <div class="col-md-12">
                    <div class="card text-white mb-4">


                        <div class="card-body">Manage All Category</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                        

                    <div class="table-responsive" style="color:black">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Category Name</th>
                                    <th>Added Date</th>
                                    <th>Action</th>
                                   
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                <th>Id</th>
                                <th>Category Name</th>
                                <th>Added Date</th>
                                <th>Action</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <?php
                                foreach($catnm as $catnm1)

                                {
                                    ?>
                                <tr>
                                    <td><?php echo $catnm1["catid"];?></td>
                                    <td><?php echo $catnm1["catname"];?></td>
                                    <td><?php echo $catnm1["added_date"];?></td>
                                    <td><a href="#" class="btn btn-sm btn-info"><span class="fa fa-book"></span> Read</a>|<a href="#" class="btn btn-sm btn-danger"><span class="fa fa-trash"></span> Delete</a>|<a href="#" class="btn btn-sm btn-success"><span class="fa fa-edit"></span> Edit</a></td>
                                
                                </tr>
                               
                                <?php
                                }

                                ?>
                            </tbody>
                        </table>
    
                    </div>
                </div>
            </div>






                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
                

                    </div>
                </div>
            </div>
        </div>
    </main>

    