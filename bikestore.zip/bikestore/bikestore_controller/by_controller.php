<?php
error_reporting(0);
 require_once("bikestore_model/by_model.php");

 class controller extends model
{
 public function __construct()

  {

  parent:: __construct();

 //register customer data in tables 

 if(isset($_POST["reg"]))
 {
     
     $unm=$_POST["uname"];
     $fnm=$_POST["fname"];
     $lnm=$_POST["lname"];
     $em=$_POST["em"];
     $pass=base64_encode($_POST["pass"]);
     $cpass=base64_encode($_POST["cpass"]);
     //upload image
     $tmp_name=$_FILES["img"]["tmp_name"];
     $type=$_FILES["img"]["type"];
     $size=$_FILES["img"]["size"]/1024;
     $path="uploads/customer/".$_FILES["img"]["name"];
     move_uploaded_file($tmp_name,$path);

     $mob=$_POST["mob"];
     $add=$_POST["add"];
     $st=$_POST["state"];
     $ct=$_POST["city"];
     
     if ($pass==$cpass) {
         $data=array("username"=>$unm,"firstname"=>$fnm,"lastname"=>$lnm,"email"=>$em,"password"=>$pass,"photo"=>$path,"mobile"=>$mob,"address"=>$add,"sid"=>$st,"ctid"=>$ct);

         $chk=$this->insalldata('bycycle_customer',$data);

         if ($chk) 
         {
             echo "<script>

         alert('You are Successfully Registered with Us')
         window.location='login';

         </script>";
         }
     }
     else

     {
       echo  "<script>


         alert('Your password does not Matched Try again')
         window.location='register';

         </script>";

     }



 }

 //fetch state in customer view in dorpdown
 $st=$this->selectalldata('bycycle_state');
 //fetch city in customer view in dorpdown
 $ct=$this->selectalldata('bycycle_city');

  //manage customer profile
  if(isset($_SESSION["custid"]))
  {

  $custid=$_SESSION["custid"]; 
  $custprof=$this->selectprofile('bycycle_customer','bycycle_state','bycycle_city','bycycle_customer.sid=bycycle_state.sid','bycycle_customer.ctid=bycycle_city.ctid','custid',$custid);

  }

 //login as customer
 if(isset($_POST["log"]))
 {
     $em=$_POST["em"];
     $pass=base64_encode($_POST["pass"]);
     $chk=$this->logincustomer('bycycle_customer',$em,$pass);
     if($chk)
     {  
         echo "<script>
         alert('You are Logged In Successfuly')
         window.location='./';
         </script>";
     }

     else
     {

      echo "<script>
      alert('Your Email and password are Incorrect Try again')
      window.location='login';
      </script>";
     }
  }


  


//update customer profile

if(isset($_POST["upd"]))
{

    $id=$_SESSION["custid"];
  
    $unm=$_POST["uname"];
    $fnm=$_POST["fname"];
    $lnm=$_POST["lname"];
    $em=$_POST["em"];
   
    //upload image
    $tmp_name=$_FILES["img"]["tmp_name"];
    $type=$_FILES["img"]["type"];
    $size=$_FILES["img"]["size"]/1024;
    $path="uploads/customer/".$_FILES["img"]["name"];
    move_uploaded_file($tmp_name,$path);

    $mob=$_POST["mob"];
    $add=$_POST["add"];
    $st=$_POST["state"];
    $ct=$_POST["city"];
    

    $chk=$this->update('bycycle_customer',$unm,$fnm,$lnm,$em,$path,$mob,$add,$st,$ct,$id);

if ($chk) 

{
            echo "<script>

        alert('Your Profile Updated succefuly')
        window.location='manage_profile';

        </script>";
        }
    }

//logout customer here

if(isset($_GET["lgout"]))
{

  
    $chk=$this->logout();
    if($chk)
    {

        echo "<script>
        alert('You are Logout Succefuly')
        window.location='./';
        </script>";

    }
    

}

   //change customer password

   if(isset($_POST["chng"]))
   {
       $custid=$_SESSION["custid"];
       $opass=base64_encode($_POST["opass"]);
       $npass=base64_encode($_POST["npass"]);
       $cpass=base64_encode($_POST["cpass"]);
       
       $chk=$this->changepassword('bycycle_customer','password','custid',$opass,$npass,$cpass,$custid);
       if($chk)
       {
           echo "<script>
           alert('Your Password Succefully Changed')
           window.location='manage_profile';
           </script>";
       }

       else
       {

           echo "<script>
           alert('Your Old pass, New pass and Confirm password does not matched try again')
           window.location='change_password';
           </script>";

       }
   }


        //forget password here

        if(isset($_POST["frg"]))
        {
            $em=$_POST["em"];
            $chk=$this->frgpassword('bycycle_customer','password',$em);
            if($chk)
            {
                echo "<script>
                alert('Your Password is :' + '$chk')
                window.location='login';
                </script>";
            }

            else
            {

                echo "<script>
                alert('Your Email does not exist Try with another Email')
                window.location='forget_password';
                </script>";

            }
        }



     //delete customer account
     if(isset($_GET["delprofile"]))
     {
         $id=$_GET["delprofile"];
         $id=array("custid"=>$id);
         $chk=$this->deldata('bycycle_customer',$id);

         if($chk)
         {
             unset($_SESSION["custid"]);
             unset($_SESSION["em"]);
             unset($_SESSION["fname"]);
             session_destroy();

             echo "<script>
             alert('Your Profile Deleted Successfully')
             window.location='./';
             </script>";
         }
     }

     //show all admin category in customer header
     $shwcat=$this->selectalldata('bycycle_addcategory');
     $shwsubcat=$this->selectalldata('bycycle_addsubcategory');
     //manage or show dynamic logo add by admin here
     $shwlogo=$this->selectalldata('bycycle_logo');


     //load products from subcategory dropdowns in customer

     if(isset($_GET["subcatdetails"]))
     {
         $id=$_GET["subcatdetails"];
         $shwprod=$this->selectallproducts('bycycle_addproduct','bycycle_addsubcategory','bycycle_addproduct.subcatid=bycycle_addsubcategory.subcatid','subcatid',$id);
     }



      //load products details 

      if(isset($_GET["pid"]))
      {
          $id=$_GET["pid"];
          $shwprod=$this->selectallproductsdetails('bycycle_addproduct','pid',$id); 
        
        }

        //add products in cart

        if(isset($_POST["addtocart"]))
        {

            $pid=$_POST["piid"];
            $custid=$_SESSION["custid"];
            $pnm=$_POST["pnname"];
            $price=$_POST["offerprice"];
            $qty=$_POST["quantity"];
            $subtot=$price*$qty;
            
            $addate=date("d/m/Y");

            $data=array("pid"=>$pid,"custid"=>$custid,"pname"=>$pnm,"price"=>$price,"quantity"=>$qty,"subtotal"=>$subtot,"added_date"=>$addate);

            $chk=$this->insalldata('bycycle_cart',$data);
            
            if($chk)
            {

                echo "<script>
                alert('Your Products successfuly added in Cart')
                window.location='ViewCart';
                </script>";
            }
        }
  //logout customer here

  if(isset($_GET["lgout"]))
  {

    
      $chk=$this->logout();
      if($chk)
      {

          echo "<script>
          alert('You are Logout Succefuly')
          window.location='login';
          </script>";

      }
      

  }

  //load our templates Here

    if($_SERVER["PATH_INFO"])
    {
      
      switch($_SERVER["PATH_INFO"])

      {
case '/':
require_once('index.php');
require_once('header.php');
require_once('content.php');
require_once('footer.php');
break;
case '/login':
require_once('index.php');
require_once('header.php');
require_once('login.php');
require_once('footer.php');
break;
// case '/catagory':
// require_once('index.php');
// require_once('header.php');
// require_once('catagory.php');
// require_once('footer.php');
// break;
case '/allproducts':
require_once('index.php');
require_once('header.php');
require_once('products.php');
require_once('footer.php');
break;

case '/productsdetails':
require_once('index.php');
require_once('header.php');
require_once('productdetails.php');
require_once('footer.php');
break;

case '/Blog':
require_once('index.php');
require_once('header.php');
require_once('latast-blog.php');

require_once('footer.php');
break;

case '/latast-blog2':
require_once('index.php');
require_once('header.php');
require_once('latast-blog2.php');
require_once('footer.php');
break;
case '/about':
require_once('index.php');
require_once('header.php');
require_once('abouts.php');
require_once('footer.php');
break;
case '/Contact':
require_once('index.php');
require_once('header.php');
require_once('contact.php');
require_once('footer.php');
break;
case '/brands':
require_once('index.php');
require_once('header.php');
require_once('brand.php');
require_once('footer.php');
break;
                
case '/return':
require_once('index.php');
require_once('header.php');
require_once('return.php');
require_once('footer.php');
break;

case '/sitemap':
require_once('index.php');
require_once('header.php');
require_once('sitemap.php');
require_once('footer.php');
break;


case '/register':
require_once('index.php');
require_once('header.php');
require_once('register.php');
require_once('footer.php');
break;


case '/forget_password':
require_once('index.php');
require_once('header.php');
require_once('forgetpassword.php');
require_once('footer.php');
break;
    

case '/manage_profile':
require_once('index.php');
require_once('header.php');
require_once('manageprofile.php');
require_once('footer.php');
break;



case '/change_password':
require_once('index.php');
require_once('header.php');
require_once('changepassword.php');
require_once('footer.php');
break;

case '/view_cart':
require_once('index.php');
require_once('header.php');
require_once('viewcart.php');
require_once('footer.php');
break;

default: 

require_once('index.php');
require_once('404.php');
require_once('footer.php');

break;

 
             }
 
           }
   }
 }
 $obj=new controller;
 
 
 
 ?>

?>