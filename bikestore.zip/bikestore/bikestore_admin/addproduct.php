<?php
if(!isset($_SESSION["aid"]))
{
    echo "<script>
    window.location='./';
    </script>";
    
}

?>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Add Product</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Add Product</li>
            </ol>
            <div class="row">
                <div class="col-md-8">
                    <div class="card text-white mb-4">
                        <div class="card-body">Add Product Form</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            
                        <form method="post" enctype="multipart/form-data">

                        <div class="form-group">
                                <select name="catname" placeholder="Enter  Category Name" class="form-control" required>
                                
                                <option value="">-select Category-</option>
                                <?php foreach($catnm as $catnm1) { ?>
                                <option value="<?php echo $catnm1["catid"];?>"><?php echo $catnm1["catname"];?></option>

                                <?php }?>
                                </select>

                            </div>


                            <div class="form-group">
                                <select name="subcatname" placeholder="Enter SubCategory Name" class="form-control" required>
                                
                                <option value="">-select SubCategory-</option>
                                <?php foreach($subcatnm as $subcatnm1) { ?>
                                <option value="<?php echo $subcatnm1["subcatid"];?>"><?php echo $subcatnm1["subcatname"];?></option>

                                <?php }?>
                                </select>

                            </div>


                            <div class="form-group">

                               Img: <input type="file" name="pimg" placeholder="Image" class="form-control" required>

                            </div>
                            
                            <div class="form-group">

                               Img1: <input type="file" name="pimg1" placeholder="Image" class="form-control" required>

                            </div>

                            
                            <div class="form-group">

                               Img2: <input type="file" name="pimg2" placeholder="Image" class="form-control" required>

                            </div>


                            
                            <div class="form-group">

                               <input type="text" name="pname" placeholder="Enter Product Name" class="form-control" required>

                            </div>
                            
                            <div class="form-group">

                                <input type="text" name="price" placeholder="Price" class="form-control" required>

                            </div>

                            
                            <div class="form-group">

                               <input type="text" name="offerprice" placeholder="Offer Price" class="form-control" required>

                            </div>



                            <div class="form-group">

<input type="text" name="qty" placeholder="Quantity" class="form-control" required>

</div>

                            
                            <div class="form-group">

                                <textarea name="pdesc" placeholder="Descriptions" class="form-control" required></textarea>

                            </div>



                            <div class="form-group">
                                <input type="date" name="addeddate" placeholder="Select Date" class="form-control" required>

                            </div>

                            <div class="form-group">
                                <input type="submit" name="addprod" class="btn btn-lg btn-primary" value="AddProduct">

                            </div>
                        </form>





                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
                

                    </div>
                </div>
            </div>
        </div>
    </main>

    