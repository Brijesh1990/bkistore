<?php
if(!isset($_SESSION["aid"]))
{
    echo "<script>
    window.location='./';
    </script>";
    
}

?>
<style>
tr:nth-child(even)
{
    background-color: lightblue;

}

tr:nth-child(odd)
{
    background-color:lighgray;

}


</style>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Manage Products</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Manage Products</li>
            </ol>
            <div class="row">
                <div class="col-md-12">
                    <div class="card text-white mb-4">


                        <div class="card-body">Manage All Products</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                        

                    <div class="table-responsive" style="color:black">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Username</th>
                                    <th>Firstname</th>
                                    <th>Lastname</th>
                                    <th>Email</th>
                                    <th>Photo</th>
                                    <th>Mobile/th>
                                    <th>Address</th>
                                    <th>Satate</th>
                                    <th>City</th>
                                   
                                    <th>Action</th>
                                   
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                <th>Id</th>
                                    <th>Username</th>
                                    <th>Firstname</th>
                                    <th>Lastname</th>
                                    <th>Email</th>
                                    <th>Photo</th>
                                    <th>Mobile</th>
                                    <th>Address</th>
                                    <th>Satate</th>
                                    <th>City</th>
                                   
                                    <th>Action</th>
                                </tr>
                            </tfoot>
                            <tbody>
                               <?php 

                               foreach ($shwcust as $shwcust1) {
                                   ?>
                                <tr>
                                    <td><?php echo $shwcust1["custid"];?></td>
                                    <td><?php echo $shwcust1["username"];?></td>
                                    <td><?php echo $shwcust1["firstname"];?></td>
                                    <td><?php echo $shwcust1["lastname"];?></td>
                                    <td><?php echo $shwcust1["email"];?></td>
                                   
                                    
                                    <td><img src="../<?php echo $shwcust1["photo"];?>" width="85px" height="85px"></td>
                                   
                                    <td><?php echo $shwcust1["mobile"];?></td>
                                    <td><?php echo $shwcust1["address"];?></td>
                                    <td><?php echo $shwcust1["sname"];?></td>
                                    <td><?php echo $shwcust1["ctname"];?></td>
                                    <td><div style="width: 150px;">
                                    <a href="<?php echo $mainurl;?>admin-managecustomer?delcustomer=<?php echo base64_encode($shwcust1["custid"]);?>" class="btn btn-sm btn-danger" onclick="return confirm('Are You sure to Delete Customer?')"><span class="fa fa-trash"></span> Delete</a>
                                    
                                    </div></td>
                                
                                </tr>
                               
                               <?php
                               }
                               ?>
                             
                            </tbody>
                        </table>
    
                    </div>
                </div>
            </div>






                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
                

                    </div>
                </div>
            </div>
        </div>
    </main>

    