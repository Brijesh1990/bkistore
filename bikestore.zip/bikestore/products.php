
<!---------catagory-banner-------->



<div class="main_breadcrumb">
	<div class="container-fluid">
		<div class="row">
		 <ul class="breadcrumb">
		   <h3><?php echo $shwprod[0]["subcatname"];?></h3>
						<li><a href="<?php echo $baseurl;?>/">Home</a></li>
						<li><a href="<?php echo $baseurl;?>catagory">Racing Bicycles</a></li>
						<li><a href="<?php echo $baseurl;?>catagory">Racing Bicycle Alminium Break</a></li>
					  </ul>
		</div>
	</div>
</div><!------catagry banner end------>
<!-----menu And products------>
<div class="main_padding product_wrapper_sec  product_wrapper">
<div id="product-category" class="container-fluid">
  <div class="row"><aside id="column-left" class="col-sm-3 hidden-xs">
    <style>
.categories_wrapper_home ul li .head .collapsed .plus {
    display: block;
}
.categories_wrapper_home ul li .head .plus {
    display: none;
}
.categories_wrapper_home ul li .head .collapsed .minus {
    display: none;
}
</style>
<div class="list-group categories_wrapper_home">
<h4>Categories</h4>
    <ul class="accordion" id="accordion-category">
		 			<li class="panel">
				<a href="#" class="">Racing Bicycles (4)</a>
				<span class="head"><a style="float:right;padding-right:5px; font-size: 18px;" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion-category" href="#category59" aria-expanded="false"><span class="plus">+</span><span class="minus">-</span></a></span>
				<div id="category59" class="panel-collapse collapse" style="clear: both; height: 0px;" aria-expanded="false">
					<ul>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Racing Bicycle Thin Tyre (0)</a>
						</li>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Racing Bicycle Alminium Frame (2)</a>
						</li>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Racing Bicycle Down Frame (2)</a>
						</li>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Racing Bicycle Magnesium (3)</a>
						</li>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Racing Bicycle Alminium Break (4)</a>
						</li>
											</ul>
				</div>
			</li>
		 			<li class="panel">
				<a href="#" class="">Baby Try Cycles (9)</a>
				<span class="head"><a style="float:right;padding-right:5px; font-size: 18px;" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion-category" href="#category60" aria-expanded="false"><span class="plus">+</span><span class="minus">-</span></a></span>
				<div id="category60" class="panel-collapse collapse" style="clear: both; height: 0px;" aria-expanded="false">
					<ul>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Tri Cycle With Push Handle (5)</a>
						</li>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Tri Cycle With Back Basket (4)</a>
						</li>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Tri Cycle With Basket (5)</a>
						</li>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Tri Cycle With Plastic Tyre (5)</a>
						</li>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Tri Cycle With Rubber Tyre (4)</a>
						</li>
											</ul>
				</div>
			</li>
		 			<li class="panel">
				<a href="#" class="">Fat Bikes (10)</a>
				<span class="head"><a style="float:right;padding-right:5px; font-size: 18px;" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion-category" href="#category61" aria-expanded="false"><span class="plus">+</span><span class="minus">-</span></a></span>
				<div id="category61" class="panel-collapse collapse" style="clear: both; height: 0px;" aria-expanded="false">
					<ul>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Aliminium Frame Body (4)</a>
						</li>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Fat Bike Front Disc (4)</a>
						</li>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Iron Frame Body (4)</a>
						</li>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Fat Bike Back Disc (4)</a>
						</li>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Fat Bike Combo Disc (4)</a>
						</li>
											</ul>
				</div>
			</li>
		 			<li class="panel">
				<a href="#" class="">Hybrid Bicycles (2)</a>
				<span class="head"><a style="float:right;padding-right:5px; font-size: 18px;" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion-category" href="#category62" aria-expanded="true"><span class="plus">+</span><span class="minus">-</span></a></span>
				<div id="category62" class="panel-collapse collapse in" style="clear: both;" aria-expanded="true">
					<ul>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Hybrid Powerfull Breaks (0)</a>
						</li>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Hybrid Bicycle With Disc (2)</a>
						</li>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Hybrid Bicycle Without Disc (1)</a>
						</li>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Hybrid Bicycle With Gear (1)</a>
						</li>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Hybrid Bicycle Without Gear (2)</a>
						</li>
											</ul>
				</div>
			</li>
		 			<li class="panel">
				<a href="#" class="">Track Bicycles (9)</a>
				<span class="head"><a style="float:right;padding-right:5px; font-size: 18px;" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion-category" href="#category63" aria-expanded="false"><span class="plus">+</span><span class="minus">-</span></a></span>
				<div id="category63" class="panel-collapse collapse" style="clear: both; height: 0px;" aria-expanded="false">
					<ul>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Track Bicycle Heavy Body (2)</a>
						</li>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Track Bicycle With Adustable Seat (2)</a>
						</li>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Track Bicycle Sports Look (1)</a>
						</li>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Track Bicycle With Adustable Handle (3)</a>
						</li>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Track Bicycle With Thick Tyre (2)</a>
						</li>
											</ul>
				</div>
			</li>
		 			<li class="panel">
				<a href="#" class="">Motorized Bicycles (7)</a>
				<span class="head"><a style="float:right;padding-right:5px; font-size: 18px;" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion-category" href="#category64" aria-expanded="false"><span class="plus">+</span><span class="minus">-</span></a></span>
				<div id="category64" class="panel-collapse collapse" style="clear: both; height: 0px;" aria-expanded="false">
					<ul>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Motorized Bicycle 4 Batteries (2)</a>
						</li>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Motorized Bicycle 6 Batteries (1)</a>
						</li>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Motorized Bicycle With Accessories (2)</a>
						</li>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Motorized Bicycle Without Paddle (2)</a>
						</li>
												<li>
							 <a href="<?php echo $mainurl;?>/product-header">Motorized Bicycle With Paddle (2)</a>
						</li>
											</ul>
				</div>
			</li>
		  
	  </ul>
</div>





<!----products features---------->
    <div class="siderber_products all_in_one_products_wrapper wrapere_siderber_products">
	<div class="left_comman_title">
		<h3 style="font-size: 14px;">Featured Product</h3>
	</div>
		<div class=" product-section">
			<div id="product_sidebar0" class="owl-carousel owl-theme" style="opacity: 1; display: block;">
		
						<div class="owl-wrapper-outer"><div class="owl-wrapper" style="width: 992px; left: 0px; display: block; transition: all 800ms ease 0s; transform: translate3d(-248px, 0px, 0px);"><div class="owl-item" style="width: 248px;"><div class="product-layout item">
			  					<div class="product-thumb transition second_products_wrapper thard_products_wrapper">
							<!--products _icons and Hover -->
						
							<div class="col-sm-4 col_a">
								<div class="">
									<div class="image"><a href="#"><img src="<?php echo  $baseurl;?>image/png3.png" alt="Bicycles Almi.." title="Bicycles Almi.." class="img-responsive"></a></div>
									<!-- Quick view icon-->
								</div>		
							</div>				
							<div class="col-sm-8 products_text_head">
								<div class="caption products_text_matter">
									<!--review_status -->
									<h4><a href="product-header.html">Bicycles Almi..</a></h4>
								
									
									 <!-- <p>More room to move.
		
			With 80GB or 160GB of storage and up to 40 hours of battery life, the new..</p>  -->
														                <p class="price">  
									  $122.00
									  									  <!--  <span class="price-tax">Ex Tax: $100.00</span>  --> 
									 </p>
																			<div class="rating">
								<span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>						<span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>						<span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>  					 <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
										  										  									
									</div>
									<button type="button"> <span class="add_tocart"> Add to Cart</span></button>
								</div>  
							</div>  
							
						</div>
									<div class="product-thumb transition second_products_wrapper thard_products_wrapper">
							<!--products _icons and Hover -->
						
							<div class="col-sm-4 col_a">
								<div class="">
									<div class="image"><a href="#"><img src="<?php echo $baseurl;?>image/png2.png" alt="Gear Bicycle.." title="Gear Bicycle.." class="img-responsive"></a></div>
									<!-- Quick view icon-->
								</div>		
							</div>				
							<div class="col-sm-8 products_text_head">
								<div class="caption products_text_matter">
									<!--review_status -->
									<h4><a href="product-header.html">Gear Bicycle..</a></h4>
								
									
									 <!-- <p>The 30-inch Apple Cinema HD Display delivers an amazing 2560 x 1600 pixel resolution. Designed speci..</p>  -->
										<p class="price">  <span class="price-old">$122.00</span> <span class="price-new">$110.00</span>  									  <!--  <span class="price-tax">Ex Tax: $90.00</span>  --> 
									 </p>
																			<div class="rating">
										  			<span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span><span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span><span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span><span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
										  										  									
									</div>
									<button type="button" > <span class="add_tocart"> Add to Cart</span></button>
								</div>  
							</div>  
							
						</div>
									<div class="product-thumb transition second_products_wrapper thard_products_wrapper">
							<!--products _icons and Hover -->
						
							<div class="col-sm-4 col_a">
								<div class="">
									<div class="image"><a href="#"><img src="<?php echo $baseurl;?>image/png2.png" alt="Suspension MT.." title="Suspension MT.." class="img-responsive"></a></div>
									<!-- Quick view icon-->
								</div>		
							</div>				
							<div class="col-sm-8 products_text_head">
								<div class="caption products_text_matter">
									<!--review_status -->
									<h4><a href="product-header.html">Suspension MT..</a></h4>
								
									
									 <!-- <p>Canon's press material for the EOS 5D states that it 'defines (a) new D-SLR category', while we're n..</p>  -->
														                <p class="price">  <span class="price-old">$122.00</span> <span class="price-new">$98.00</span>  									  <!--  <span class="price-tax">Ex Tax: $80.00</span>  --> 
									 </p>
																			<div class="rating">
										    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>		
										    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>		
										    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>	  	
										    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
							  						<span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
										  										  									
									</div>
									<button type="button" > <span class="add_tocart"> Add to Cart</span></button>
								</div>  
							</div>  
							
						</div>
								 </div></div><div class="owl-item" style="width: 248px;"><div class="product-layout item">
			  					<div class="product-thumb transition second_products_wrapper thard_products_wrapper">
							<!--products _icons and Hover -->
						
							<div class="col-sm-4 col_a">
								<div class="">
									<div class="image"><a href="#"><img src="<?php echo $baseurl;?>image/png2.png" alt=" Blue Suspens.." title=" Blue Suspens.." class="img-responsive"></a></div>
									<!-- Quick view icon-->
								</div>		
							</div>				
							<div class="col-sm-8 products_text_head">
								<div class="caption products_text_matter">
									<!--review_status -->
									<h4><a href="product-header.html"> Blue Suspens..</a></h4>
								
														                <p class="price">  $122.00
									  									  <!--  <span class="price-tax">Ex Tax: $100.00</span>  --> </p>
										<div class="rating">
										  		<span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>	
										  		<span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
								  				 <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                 <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
										  										  									
									</div>
									<button type="button" > <span class="add_tocart"> Add to Cart</span></button>
								</div>  
							</div>  
							
						</div>
									<div class="product-thumb transition second_products_wrapper thard_products_wrapper">
							<!--products _icons and Hover -->
						
							<div class="col-sm-4 col_a">
								<div class="">
									<div class="image"><a href="#"><img src="<?php echo $baseurl;?>image/png6.png" alt="E-Bicycle.." title="E-Bicycle.." class="img-responsive"></a></div>
									<!-- Quick view icon-->
								</div>		
							</div>				
							<div class="col-sm-8 products_text_head">
								<div class="caption products_text_matter">
									<!--review_status -->
									<h4><a href="product-header.html">E-Bicycle..</a></h4>
								
									
									 <!-- <p>HTC Touch - in High Definition. Watch music videos and streaming content in awe-inspiring high defin..</p>  -->
														                <p class="price">  <span class="price-old">$122.00</span> <span class="price-new">$38.00</span>  									  <!--  <span class="price-tax">Ex Tax: $30.00</span>  --> 
									 </p>
					<div class="rating">
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
							<span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>						
							  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
								<span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
							 <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
										  										  									
						</div>
									<button type="button"> <span class="add_tocart"> Add to Cart</span></button>
								</div>  
							</div>  
							
						</div>
								 </div></div></div></div> 
						 
					<div class="owl-controls clickable"><div class="owl-buttons"><div class="owl-prev"><i class="fa fa-angle-left fa-5x"></i></div><div class="owl-next"><i class="fa fa-angle-right fa-5x"></i></div></div></div></div> 
	</div>
</div>

 
 <script>
 $(document).ready(function(){
	$('#product_sidebar0').owlCarousel({	
		items: 1,
		itemsDesktop:[1199,1],
		itemsDesktopSmall:[992,3],
		itemsTablet:[768,2],
		itemsMobile:[450,1],
		autoPlay: 6000,
		pagination: false,
		navigation: true,
		navigationText: ['<i class="fa fa-angle-left fa-5x"></i>', '<i class="fa fa-angle-right fa-5x"></i>']
	});
});   
		 </script>
    <div class="swiper-viewport">
  <div id="banner0" class="swiper-container swiper-container-horizontal swiper-container-fade">
    <div class="swiper-wrapper" style="transition-duration: 0ms;">      
    	<div class="swiper-slide swiper-slide-active" style="width: 278px; opacity: 1; transform: translate3d(0px, 0px, 0px); transition-duration: 0ms;"><a href="#"><img src="<?php echo $baseurl;?>image/dsdd-270x350.jpg" alt="HP Banner" class="img-responsive"></a></div>
            <div class="swiper-slide swiper-slide-next" style="width: 278px; opacity: 0; transform: translate3d(-278px, 0px, 0px); transition-duration: 0ms;"><a href="#"><img src="<?php echo $baseurl;?>image/ssss-270x350.jpg" alt="HP Banner2" class="img-responsive"></a></div>
      </div>
  </div>
</div>
<script type="text/javascript">
$('#banner0').swiper({
	effect: 'fade',
	autoplay: 2500,
    autoplayDisableOnInteraction: false
});
</script> 
  </aside>

                <div id="content" class="col-sm-9">
      <h3><?php echo $shwprod[0]["subcatname"];?></h3>
            <div class="row row_category">        
             <div class="col-sm-2 category_banner">  <div class="category_banner"><a href="product.html"><img src="<?php echo $baseurl;?>image/png13.png" alt="Racing Bicycle Alminium Break" title="Racing Bicycle Alminium Break" class="img-thumbnail banner-images"></a></div></div>
                        <div class="col-sm-10"><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p></div>
        </div>
		
                        <div class="category_grid-wrapper">

		
			<div class="col-md-4 col-xs-6">
				  <div class="form-group input-group input-group-sm custom-select">
					<label class="input-group-addon" for="input-sort">Sort By:</label>
						<select id="input-sort" class="form-control" onchange="location = this.value;">
						  	<option value="#" selected="selected">Default</option>
							  	<option value="#">Name (A - Z)</option>
							  	<option value="#">Name (Z - A)</option>
								  	<option value="#">Price (Low &gt; High)</option>
								  	<option value="#">Price (High &gt; Low)</option>
								  	<option value="#">Rating (Highest)</option>
							  	<option value="#">Rating (Lowest)</option>
							  	<option value="#">Model (A - Z)</option>
							 <option value="#">Model (Z - A)</option>
						</select>
				  </div>
			</div>
			<!----select value----->
			       		 
        <div class="col-md-3 col-xs-6">
			  <div class="form-group input-group input-group-sm custom-select">
				<label class="input-group-addon" for="input-limit">Show:</label>
					<select id="input-limit" class="form-control" onchange="location = this.value;">
					  		<option value="#" selected="selected">12</option>
							<option value="#">25</option>
							<option value="#">50</option>
							<option value="#">75</option>
							<option value="#">100</option>
					</select>
			  </div>
        </div>
			<!------ /end --->  
		<div class="col-md-3 col-sm-6">
          <div class="form-group"><a href="#" id="compare-total" class="btn btn-link">Product Compare (0)</a></div>
        </div>
			
		<div class="col-md-2 col-sm-6 hidden-xs">
          <div class="btn-group btn-group-sm">
            <button type="button" id="grid-view" class="btn btn-default active" data-toggle="tooltip" title="" data-original-title="Grid"><i class="fa fa-th-large"></i></button>
			 <button type="button" id="list-view" class="btn btn-default" data-toggle="tooltip" title="" data-original-title="List"><i class="fa fa-list-ul"></i></button>
          </div>
        </div>
				<div class="clear"></div>
      </div>





  <!-- products section start here -->



  <?php
                           foreach($shwprod as $shwprod1)
						   {
						   ?>


      <div class="row"> 
	          <div class="product-layout product-grid col-lg-4 col-md-4 col-sm-6 col-xs-12">
             <div class="product-thumb transition">
				  <div class="image">
					<!--image -->
					  <a href="<?php echo $mainurl;?>productsdetails?pid=<?php echo $shwprod1["pid"];?>">
							<img src="bikestore_admin/<?php echo $shwprod1["pimage"];?>" alt="Kids Bicycle" title="Kids Bicycle" class="img-responsive" style="width:90%; height: 150px;">

							<img src="bikestore_admin/<?php echo $shwprod1["pimage"];?>" alt="Kids Bicycle" title="Kids Bicycle" class="img-responsive hover-image" style="width:90%; height: 150px;">
						</a>
          <div class="hover-button button-group ">
								<button type="button"  class="addtocart" data-toggle="tooltip" data-placement="left" data-original-title="Add to Cart"><i class="fa fa-shopping-cart"></i></button>
							<div class="custom-button-group">
								  <a class="quickviewopen" href="<?php echo $mainurl;?>productsdetails?pid=<?php echo $shwprod1["pid"];?>" data-toggle="tooltip" data-placement="left" data-original-title="Quick View"><i class="fa fa-eye"></i></a>
							</div> 
								<button type="button" title=""  class="wishlist" data-toggle="tooltip" data-placement="left" data-original-title="wishlist"><i class="fa fa-heart-o"></i></button>
								<button type="button" title=""  class="compare" data-toggle="tooltip" data-placement="left" data-original-title="Compare this Product"><i class="fa fa-balance-scale"></i></button>	
							</div> 
					</div>
				  <!--products text matter -->
				  <div class="caption">
				   <div class="grid_products_section">		
					  <div class="rate-and-title">
						<div class="rating">
						  				 <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
						  			     <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
						  				 <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
						  				 <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
						  				 <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
						  	<div class="clear"></div>
						</div>
						<h4><a href="product-header.html"><?php echo $shwprod1["pname"];?></a></h4>  
							  <p class="price"> <del><?php echo $shwprod1["price"];?></del><?php echo $shwprod1["offerprice"];?>
							 <!--  <span class="price-tax">Ex Tax: $100.00</span> --></p>
							</div>
					  </div>
				  <!-- list-view style section -->
						  <div class="second_products_design list_products_section" style="display: none;">		
							  <div class="rate-and-title">		
								  <!--review_status -->
									<div class="rating">
										  	<span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
							  			    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
						  					<span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
										    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
										    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
										  										  									
									</div>
								   <h4><a href="product-header.html"><?php echo $shwprod1["pname"];?></a></h4>
										<p class="price"><?php echo $shwprod1["offerprice"];?></p>
<p>Stop your co-workers in their tracks with the stunning new 30-inch diagonal HP LP3065 Flat Panel Mon..</p>
<button type="button"  class="addtocart"><i class="fa fa-shopping-cart"></i> Add to Cart </button>
											
									 <div class="second_button_desgin"> 
												<div class="button-group custom-button-group">
													
											<button type="button" title="Add to Wish List" class="products_wishlist"><i class="fa fa-heart-o"></i></button>
												<div class="custom-button-group">
													<a class="quickviewopen" href="product.html"><i class="fa fa-eye"></i></a>
												</div> 
													
													<button type="button" title="Compare this Product"  class="products_wishlist"><i class="fa fa-signal"></i></button>
												</div> 
											</div>



									<div class="clear"></div>
							  </div>
						</div>	  
				</div>
        </div>
        </div>



		<?php
						   }
						   ?>

										
									
									<div class="clear"></div>
							  </div>
						</div>	  
				</div>
        </div>
        </div>
         </div>
         <script>
 $('.quickviewopen').magnificPopup({
	disableOn: 700,
	type: 'iframe',
	mainClass: 'mfp-fade',
	removalDelay: 160,
	preloader: true,
	fixedContentPos: true
});

 $(document).ready(function(){
	$('#featured_product_filter').owlCarousel({	
		items: 5,
		itemsDesktop:[1199,4],
		itemsDesktopSmall:[992,3],
		itemsTablet:[768,2],
		itemsMobile:[450,1],
		autoPlay: 6000,
		pagination: false,
		navigation: true,
		navigationText: ['<i class="fa fa-angle-left fa-5x"></i>', '<i class="fa fa-angle-right fa-5x"></i>']
	});
});      


 $(document).ready(function(){
	$('#latest_product_filter').owlCarousel({	
		items: 5,
		itemsDesktop:[1199,4],
		itemsDesktopSmall:[992,3],
		itemsTablet:[768,2],
		itemsMobile:[450,1],
		autoPlay: 6000,
		pagination: false,
		navigation: true,
		navigationText: ['<i class="fa fa-angle-left fa-5x"></i>', '<i class="fa fa-angle-right fa-5x"></i>']
	});
});      


 $(document).ready(function(){
	$('#bestseller_product_filter').owlCarousel({	
		items: 5,
		itemsDesktop:[1199,4],
		itemsDesktopSmall:[992,3],
		itemsTablet:[768,2],
		itemsMobile:[450,1],
		autoPlay: 6000,
		pagination: false,
		navigation: true,
		navigationText: ['<i class="fa fa-angle-left fa-5x"></i>', '<i class="fa fa-angle-right fa-5x"></i>']
	});
});      


 $(document).ready(function(){
	$('#special_product_filter').owlCarousel({	
		items: 5,
		itemsDesktop:[1199,4],
		itemsDesktopSmall:[992,3],
		itemsTablet:[768,2],
		itemsMobile:[450,1],
		autoPlay: 6000,
		pagination: false,
		navigation: true,
		navigationText: ['<i class="fa fa-angle-left fa-5x"></i>', '<i class="fa fa-angle-right fa-5x"></i>']
	});
});      
</script>
		
      <div class="row">
        
        <div class="col-sm-6 text-left">Showing 1 to 4 of 4 (1 Pages)</div>
		<div class="col-sm-6 text-right"></div>
      </div>
                  </div>
    </div>
</div></div>
