<?php
class model
{
 
    public $connection="";
    public function __construct()
    {
        session_start();

        try {

            // $this->connection=mysqli_connect("localhost", "root", "", "mvc_app");
            
            // echo "success";
            // or
            
            // $this->connection=new mysqli("localhost", "root", "", "bycycle");
            //echo "success";
            
            $ser="localhost";
            $user="root";
            $pass="";
            $dbname="bycycle";
            $this->connection=new mysqli($ser,$user,$pass,$dbname);
        


           //connect with live server cpanel hosting details

            // $ser="sql204.byethost33.com";
            // $user="b33_28063524";
            // $pass="b12345";
            // $dbname="b33_28063524_bycycle";
            // $this->connection=new mysqli($ser,$user,$pass,$dbname);
        }
        catch(Exception $e)
        {
            die(mysqli_error($this->connection,$e));
        }

        //mysqli_close($this->connection);
    }


    //create a member function for insertalldata
    public function insalldata($table,$data)
    {

        $column=array_keys($data);
        $column1=implode(",",$column);

        $value=array_values($data);
        $value1=implode("','",$value);
        
        $insert="insert into $table($column1) values('$value1')";
        $query=mysqli_query($this->connection,$insert);
        return $query;

    }

    //create a member function for selectalldata

    public function selectalldata($table) 

    {
       $select="select * from $table";
       $query=mysqli_query($this->connection,$select);
       while($result=mysqli_fetch_array($query))

       {
          
        $arr[]=$result;
       }

       return $arr;

    }


    
    //create a member function for selectalldata

    public function selectallproducts($table,$table1,$where,$column,$id) 

    {
        $select="select * from $table join $table1 on $where where $table.$column='$id'";
       $query=mysqli_query($this->connection,$select);
       while($result=mysqli_fetch_array($query))

       {
          
        $arr[]=$result;
       }

       return $arr;

    }


    
    //create a member function for selectproducts details

    public function selectallproductsdetails($table,$column,$id) 

    {
        $select="select * from $table where $column='$id'";
       $query=mysqli_query($this->connection,$select);
       while($result=mysqli_fetch_array($query))

       {
          
        $arr[]=$result;
       }

       return $arr;

    }
    
//create a member function for selectalldata
public function selectprofile($table,$table1,$table2,$where,$where1,$column,$custid) 

{
    
    // select * from $table join $table1 on $table.sid=$table1.sid join $table2 on $table.ctid=$table2.ctid;
    
    $select="select * from $table join $table1 on $where join $table2 on $where1 where $column='$custid'";
    $query=mysqli_query($this->connection,$select);
    while($result=mysqli_fetch_array($query))
    {
        
    $arr[]=$result;

    }

    return $arr;

}

    //create a member function for Login

    public function logincustomer($table,$em,$pass)
    {
        
        $select="select * from $table where email='$em' and password='$pass'";
        $query=mysqli_query($this->connection,$select);
        $result=mysqli_fetch_array($query);
        $no=mysqli_num_rows($query);
        if($no==1)
        {
            $_SESSION["custid"]=$result["custid"];
            $_SESSION["fname"]=$result["firstname"];
            $_SESSION["em"]=$result["email"];

            return true;

        }

        else
        {
             return false;
        }


    }


    //create a forgetpassword member function

    public function frgpassword($table,$clnm,$em)
    {

       $select="select $clnm  from $table where email='$em'";
       $query=mysqli_query($this->connection,$select);
       $result=mysqli_fetch_array($query);
       $no=mysqli_num_rows($query);
       if($no==1)
       {
           $p=base64_decode($result["password"]);
           return $p;
       }
       else
       {
           return false;
       }
    }

//create a meber function for change password

public function changepassword($table,$column,$column1,$opass,$npass,$cpass,$custid)
{
 
    $select="select $column  from $table where $column1='$custid'";
    $query=mysqli_query($this->connection,$select);
    $result=mysqli_fetch_array($query);
    $p=$result["password"];
    if($p==$opass && $npass==$cpass)
    {
        $upd="update $table set $column='$npass' where $column1='$custid'";
        $query=mysqli_query($this->connection,$upd);
        return $query;
    }
    else
    {
        return false;
    }

}

//create a meber function for deldata
public function deldata($table,$id)
{

    $column=array_keys($id);
    $field=implode(",",$column);

    $value=array_values($id);
    $value1=implode("','",$value);

    $del="delete from $table where $field='$value1'";
    $query=mysqli_query($this->connection,$del);
    return $query;

}


//create a meber function for update profile
public function update($table,$unm,$fnm,$lnm,$em,$path,$mob,$add,$st,$ct,$id)
{

    $upd="update $table set username='$unm',firstname='$fnm',lastname='$lnm',email='$em',photo='$path',mobile='$mob',address='$add',sid='$st',ctid='$ct' where custid='$id'";
    $query=mysqli_query($this->connection,$upd);
    return $query;



}

//create a meber function for logout here

public function logout()

{
   
   unset($_SESSION["custid"]);
   unset($_SESSION["fname"]);
   unset($_SESSION["em"]);

   session_destroy();

   return true;



}

}


?>