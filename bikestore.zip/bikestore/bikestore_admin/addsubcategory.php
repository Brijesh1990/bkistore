<?php
if(!isset($_SESSION["aid"]))
{
    echo "<script>
    window.location='./';
    </script>";
    
}

?>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Add Sub Category</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Add Sub Category</li>
            </ol>
            <div class="row">
                <div class="col-md-8">
                    <div class="card text-white mb-4">
                        <div class="card-body">Add Sub Category Form</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            
                        <form method="post">
                            
                        <div class="form-group">
                                <select name="catname" placeholder="Enter  Category Name" class="form-control" required>
                                
                                <option value="">-select Category-</option>
                                <?php foreach($catnm as $catnm1) { ?>
                                <option value="<?php echo $catnm1["catid"];?>"><?php echo $catnm1["catname"];?></option>

                                <?php }?>
                                </select>

                            </div>
                            
                            <div class="form-group">
                                <input type="text" name="subcatname" placeholder="Enter Sub Category Name" class="form-control" required>

                            </div>

                            <div class="form-group">
                                <input type="date" name="addeddate" placeholder="Select Date" class="form-control" required>

                            </div>

                            <div class="form-group">
                                <input type="submit" name="addsubcat" class="btn btn-lg btn-primary" value="AddSubCategory">

                            </div>
                        </form>





                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
                

                    </div>
                </div>
            </div>
        </div>
    </main>

    