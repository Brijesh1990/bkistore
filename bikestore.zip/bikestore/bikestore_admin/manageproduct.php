<?php
if(!isset($_SESSION["aid"]))
{
    echo "<script>
    window.location='./';
    </script>";
    
}

?>
<style>
tr:nth-child(even)
{
    background-color: lightblue;

}

tr:nth-child(odd)
{
    background-color:lighgray;

}


</style>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Manage Products</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Manage Products</li>
            </ol>
            <div class="row">
                <div class="col-md-12">
                    <div class="card text-white mb-4">


                        <div class="card-body">Manage All Products</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                        

                    <div class="table-responsive" style="color:black">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>CategoryName</th>
                                    <th>SubCategoryName</th>
                                    <th>Image</th>
                                    <th>Image1</th>
                                    <th>Image2</th>
                                    <th>Pname</th>
                                    <th>Price</th>
                                    <th>Offerprice</th>
                                    <th>qty</th>
                                    <th>Descriptions</th>
                                    <th>Added Date</th>
                                    <th>Action</th>
                                   
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                <th>Id</th>
                                    <th>CategoryName</th>
                                    <th>SubCategoryName</th>
                                    <th>Image</th>
                                    <th>Image1</th>
                                    <th>Image2</th>
                                    <th>Pname</th>
                                    <th>Price</th>
                                    <th>Offerprice</th>
                                    <th>qty</th>
                                    <th>Descriptions</th>
                                    <th>Added Date</th>
                                    <th>Action</th>
                                </tr>
                            </tfoot>
                            <tbody>
                               <?php 

                               foreach ($shwprod as $shwprod1) {
                                   ?>
                                <tr>
                                    <td><?php echo $shwprod1["pid"];?></td>
                                    <td><?php echo $shwprod1["catname"];?></td>
                                    <td><?php echo $shwprod1["subcatname"];?></td>
                                    <td><img src="<?php echo $shwprod1["pimage"];?>" width="85px" height="85px"></td>
                                    <td><img src="<?php echo $shwprod1["pimage1"];?>" width="85px" height="85px"></td>
                                    <td><img src="<?php echo $shwprod1["pimage2"];?>" width="85px" height="85px"></td>
                                    <td><?php echo $shwprod1["pname"];?></td>
                                    <td><?php echo $shwprod1["price"];?></td>
                                    <td><?php echo $shwprod1["offerprice"];?></td>
                                    <td><?php echo $shwprod1["qty"];?></td>
                                    <td><?php echo $shwprod1["description"];?></td>
                                    <td><?php echo $shwprod1["added_date"];?></td>

                                    <td><div style="width: 150px;">
                                    <a href="<?php echo $mainurl;?>admin-manageproduct?delproduct=<?php echo base64_encode($shwprod1["pid"]);?>" class="btn btn-sm btn-danger" onclick="return confirm('Are You sure to Delete This Products?')"><span class="fa fa-trash"></span> Delete</a>
                                    
                                    |<a href="#" class="btn btn-sm btn-success"><span class="fa fa-edit"></span> Edit</a></div></td>
                                
                                </tr>
                               
                               <?php
                               }
                               ?>
                             
                            </tbody>
                        </table>
    
                    </div>
                </div>
            </div>






                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
                

                    </div>
                </div>
            </div>
        </div>
    </main>

    