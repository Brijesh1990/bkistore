<div id="layoutError">
    <div id="layoutError_content">
        <main>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <div class="text-center mt-4">
                            <br><br><br>
                            <img class="mb-4 img-error" src="<?php echo $baseurl;?>assets/img/404-Error.png" />
                            <p class="lead">This requested URL was not found on this server.</p>
                            <a href="<?php echo $mainurl;?>admin-dashboard">
                                <i class="fas fa-arrow-left mr-1"></i> Return to Dashboard
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <div id="layoutError_footer">




    </div>
</div>