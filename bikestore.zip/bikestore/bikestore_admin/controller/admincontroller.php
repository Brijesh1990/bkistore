<?php
require_once("model/adminmodel.php");
class admincontroller extends adminmodel
{
    public function __construct()
    {

        parent:: __construct();

        //login as admin

        if(isset($_POST['log']))
        {
          $em=$_POST["em"];
          
          $pass=$_POST["pass"];
          $chk=$this->adminlogin('bycycle_admin',$em,$pass);

          if($chk)
          {
              echo "<script>
              alert('You are Logged In as Admin Successfuly')
              window.location='admin-dashboard';
              </script>";
          }

          else

          {
            echo "<script>
            alert('Your Email and Password are Incorrect Try again')
            window.location='./';
            </script>";
          }

        }

        //add admin category here
        if(isset($_POST["addsubcat"]))
        {
            $catnm=$_POST["catname"];
            $subcatnm=$_POST["subcatname"];
            $addate=$_POST["addeddate"];
            $data=array("catid"=>$catnm,"subcatname"=>$subcatnm,"addedsubcategory_date"=>$addate);
            $chk=$this->insalldata('bycycle_addsubcategory',$data);
            if($chk)
          {
              echo "<script>
              alert('Your SubCategory Added Succesfully')
              window.location='admin-addsubcategory';
              </script>";
          }

        }

        //manage all subcategory or show subcategory
        $subcatnm=$this->selectjoinalldata('bycycle_addsubcategory','bycycle_addcategory','bycycle_addsubcategory.catid=bycycle_addcategory.catid');


         //add admin category here
         if(isset($_POST["addcat"]))
         {
             $catnm=$_POST["catname"];
             $addate=$_POST["addeddate"];
             $data=array("catname"=>$catnm,"added_date"=>$addate);
             $chk=$this->insalldata('bycycle_addcategory',$data);
             if($chk)
           {
               echo "<script>
               alert('Your Category Added Succesfully')
               window.location='admin-addcategory';
               </script>";
           }
 
         }
 
         //manage all category or show category
         $catnm=$this->selectalldata('bycycle_addcategory');

  //add customer logo by admin here
  if(isset($_POST["addlogo"]))
  {
      $tmp_name=$_FILES["img"]["tmp_name"];
      $path="uploads/customer_logo/".$_FILES["img"]["name"];
      move_uploaded_file($tmp_name,$path);
        
      $addate=$_POST["addeddate"];
      $status=$_POST["status"];
      $data=array("photo"=>$path,"added_date"=>$addate,"status"=>$status);
      
      $chk=$this->insalldata('bycycle_logo',$data);
      if($chk)
    {
        echo "<script>
        alert('Your Logo Added Succesfully')
        window.location='AddLogo';
        </script>";
    }

  }

  //manage customer logo
  $logo=$this->selectalldata('bycycle_logo');

//add admin Products here
if(isset($_POST["addprod"]))
{
    $catnm=$_POST["catname"];
    $subcatnm=$_POST["subcatname"];
    // upload product image1
    $tmp_name=$_FILES["pimg"]["tmp_name"];
    $path="uploads/products_images/".$_FILES["pimg"]["name"];
    move_uploaded_file($tmp_name,$path);
    // upload product image2
    $tmp_name1=$_FILES["pimg1"]["tmp_name"];
    $path1="uploads/products_images/".$_FILES["pimg1"]["name"];
    move_uploaded_file($tmp_name1,$path1);
    // upload product image3
    $tmp_name2=$_FILES["pimg2"]["tmp_name"];
    $path2="uploads/products_images/".$_FILES["pimg2"]["name"];
    move_uploaded_file($tmp_name2,$path2);

    $pnm=$_POST["pname"];
    $price=$_POST["price"];
    $offerprice=$_POST["offerprice"];
    $qty=$_POST["qty"];
    $pdesc=$_POST["pdesc"];
    $addate=$_POST["addeddate"];

    $data=array("catid"=>$catnm,"subcatid"=>$subcatnm,"pimage"=>$path,"pimage1"=>$path1,"pimage2"=>$path2,"pname"=>$pnm,"price"=>$price,"offerprice"=>$offerprice,"qty"=>$qty,"description"=>$pdesc,"added_date"=>$addate);
    $chk=$this->insalldata('bycycle_addproduct',$data);
    if($chk)
{
    echo "<script>
    alert('Your Product Added Succesfully')
    window.location='admin-addproduct';
    </script>";
}

}


//manage all products

$shwprod=$this->selectjoinalldata1('bycycle_addproduct','bycycle_addcategory','bycycle_addsubcategory','bycycle_addproduct.catid=bycycle_addcategory.catid','bycycle_addproduct.subcatid=bycycle_addsubcategory.subcatid');


//delete a products from admin
if(isset($_GET["delproduct"]))
{
 $delid=base64_decode($_GET["delproduct"]);
 $id=array("pid"=>$delid);
$chk=$this->deldata('bycycle_addproduct',$id);
if($chk)
{
    echo "<script>
    alert('Product Deleted Succefully')
    window.location='admin-manageproduct';
    
    </script>";
}
else
{

    echo "<script>
    alert('Somthing went wrong while deleteing Products')
    window.location='admin-manageproduct';
    
    </script>";


}
}

//manage all customers

$shwcust=$this->managecustomers('bycycle_customer','bycycle_state','bycycle_city','bycycle_customer.sid=bycycle_state.sid','bycycle_customer.ctid=bycycle_city.ctid');

//delete a customer

if(isset($_GET["delcustomer"]))
{
    $delid=base64_decode($_GET["delcustomer"]);
    $id=array("custid"=>$delid);
    $chk=$this->deldata('bycycle_customer',$id);
    {

        echo "<script>
        alert('Customer Deleted Succefully')
        window.location='admin-managecustomer';
        
        </script>";     

    }
}


//read a subcategory data

if(isset($_GET["readsubcat"]))
{
 $id=base64_decode($_GET["readsubcat"]);
 $shwsubcat=$this->readalldata('bycycle_addsubcategory','bycycle_addcategory','subcatid',$id,'bycycle_addsubcategory.catid=bycycle_addcategory.catid'); 

}

//delete a read data of subcategory

if(isset($_GET["delsubcatdata"]))
{
    $delid=base64_decode($_GET["delsubcatdata"]);
    $id=array("subcatid"=>$delid);
    $chk=$this->deldata('bycycle_addsubcategory',$id);
    {

        echo "<script>
        alert('Subcategory Deleted Succefully')
        window.location='admin-managesubcategory';
        
        </script>";     

    }
}

//update subcategory

if(isset($_POST["updsubcat"]))
{
 
    $id=base64_decode($_GET["readsubcat"]);
    $catnm=$_POST["catname"];
    $subcatnm=$_POST["subcatname"];
    $addate=$_POST["addeddate"];
    $data=array("catid"=>$catnm,"subcatname"=>$subcatnm,"addedsubcategory_date"=>$addate);

    $chk=$this->updsubcategory('bycycle_addsubcategory',$catnm,$subcatnm,$addate,'subcatid',$id);


    if($chk)
  {
      echo "<script>
      alert('Your SubCategory Updated Succesfully')
      window.location='admin-managesubcategory';
      </script>";
  }


}

//count total numbers of customere
$shwtotalcustomer=$this->countdata('bycycle_customer','custid');

//count total numbers of category
$shwtotalcategory=$this->countdata('bycycle_addcategory','catid');
//logout here

if(isset($_GET["lgout"]))
{

    $chk=$this->logout();
    if($chk)
    {
        echo "<script>
        alert('You are Logout  as Admin Successfuly')
        window.location='./';
        </script>";
    }

}
        //load your admin template view
        if($_SERVER["PATH_INFO"])
        {
            switch($_SERVER["PATH_INFO"])
            {
                case '/':
                    require_once("index.php");
                    require_once("login.php");
                    require_once("footer.php");
                    break;
                case '/admin-dashboard':
                    require_once("index.php");
                    require_once("header.php");
                    require_once("sidebar.php");
                    require_once("dashboard.php");
                    require_once("footer.php");
                    break;

                case '/admin-managecustomer':
                    require_once("index.php");
                    require_once("header.php");
                    require_once("sidebar.php");
                    require_once("managecustomers.php");
                    require_once("footer.php");
                    break;

                case '/admin-addcategory':
                    require_once("index.php");
                    require_once("header.php");
                    require_once("sidebar.php");
                    require_once("addcategory.php");
                    require_once("footer.php");
                    break;
                case '/admin-managecategory':
                    require_once("index.php");
                    require_once("header.php");
                    require_once("sidebar.php");
                    require_once("managecategory.php");
                    require_once("footer.php");
                    break;



                case '/admin-addsubcategory':
                    require_once("index.php");
                    require_once("header.php");
                    require_once("sidebar.php");
                    require_once("addsubcategory.php");
                    require_once("footer.php");
                    break;
                case '/admin-managesubcategory':
                    require_once("index.php");
                    require_once("header.php");
                    require_once("sidebar.php");
                    require_once("managesubcategory.php");
                    require_once("footer.php");
                    break;
                    
                case '/admin-readsubcategory':
                    require_once("index.php");
                    require_once("header.php");
                    require_once("sidebar.php");
                    require_once("readsubcategory_data.php");
                    require_once("footer.php");
                    break;

                case '/admin-editsubcategory':
                    require_once("index.php");
                    require_once("header.php");
                    require_once("sidebar.php");
                    require_once("editsubcategory.php");
                    require_once("footer.php");
                    break;
    

                    
                case '/admin-addproduct':
                    require_once("index.php");
                    require_once("header.php");
                    require_once("sidebar.php");
                    require_once("addproduct.php");
                    require_once("footer.php");
                    break;
                case '/admin-manageproduct':
                    require_once("index.php");
                    require_once("header.php");
                    require_once("sidebar.php");
                    require_once("manageproduct.php");
                    require_once("footer.php");
                    break;

                case '/AddLogo':
                    require_once("index.php");
                    require_once("header.php");
                    require_once("sidebar.php");
                    require_once("addlogo.php");
                    require_once("footer.php");
                    break;

                default:
                require_once("index.php");
                require_once("header.php");
                require_once("404.php");
                require_once("footer.php");
                break;
                    
                    
            }

        }

    }
}

$obj=new admincontroller;
?>