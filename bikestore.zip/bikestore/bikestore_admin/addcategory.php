<?php
if(!isset($_SESSION["aid"]))
{
    echo "<script>
    window.location='./';
    </script>";
    
}

?>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Add Category</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Add Category</li>
            </ol>
            <div class="row">
                <div class="col-md-8">
                    <div class="card text-white mb-4">
                        <div class="card-body">Add Category Form</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            
                        <form method="post">
                            <div class="form-group">
                                <input type="text" name="catname" placeholder="Enter Category Name" class="form-control" required>

                            </div>

                            <div class="form-group">
                                <input type="date" name="addeddate" placeholder="Select Date" class="form-control" required>

                            </div>

                            <div class="form-group">
                                <input type="submit" name="addcat" class="btn btn-lg btn-primary" value="AddCategory">

                            </div>
                        </form>





                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
                

                    </div>
                </div>
            </div>
        </div>
    </main>

    