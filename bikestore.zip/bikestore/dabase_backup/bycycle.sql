-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 10, 2021 at 07:15 AM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bycycle`
--

-- --------------------------------------------------------

--
-- Table structure for table `bycycle_addcategory`
--

CREATE TABLE `bycycle_addcategory` (
  `catid` int(11) NOT NULL,
  `catname` varchar(255) NOT NULL,
  `added_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bycycle_addcategory`
--

INSERT INTO `bycycle_addcategory` (`catid`, `catname`, `added_date`) VALUES
(1, 'Racing Bicycles', '2021-02-17'),
(2, 'Baby Try Cycles', '2021-02-17'),
(3, 'Hibrid Bicycles', '2021-02-17'),
(4, 'Track Bicycles', '2021-02-17'),
(5, 'Fat Bicycles', '2021-02-17');

-- --------------------------------------------------------

--
-- Table structure for table `bycycle_addproduct`
--

CREATE TABLE `bycycle_addproduct` (
  `pid` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `subcatid` int(11) NOT NULL,
  `pimage` varchar(255) NOT NULL,
  `pimage1` varchar(255) NOT NULL,
  `pimage2` varchar(255) NOT NULL,
  `pname` varchar(255) NOT NULL,
  `price` float NOT NULL,
  `offerprice` float NOT NULL,
  `qty` int(11) NOT NULL,
  `description` text NOT NULL,
  `added_date` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bycycle_addproduct`
--

INSERT INTO `bycycle_addproduct` (`pid`, `catid`, `subcatid`, `pimage`, `pimage1`, `pimage2`, `pname`, `price`, `offerprice`, `qty`, `description`, `added_date`) VALUES
(1, 1, 1, 'uploads/products_images/html1.jpg', 'uploads/products_images/html1.jpg', 'uploads/products_images/html1.jpg', 'hero thin type bycycle005 sports', 8500, 7600, 1, 'good', '2021-03-03'),
(2, 2, 6, 'uploads/products_images/png4-80x80.png', 'uploads/products_images/png4-80x80.png', 'uploads/products_images/png4-80x80.png', 'Baby tri bycycle sports model', 4500, 3200, 1, 'good', '2021-02-24');

-- --------------------------------------------------------

--
-- Table structure for table `bycycle_addsubcategory`
--

CREATE TABLE `bycycle_addsubcategory` (
  `subcatid` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `subcatname` varchar(255) NOT NULL,
  `addedsubcategory_date` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bycycle_addsubcategory`
--

INSERT INTO `bycycle_addsubcategory` (`subcatid`, `catid`, `subcatname`, `addedsubcategory_date`) VALUES
(1, 1, 'Racing Bicycle thin tyre', '2021-02-19'),
(2, 1, 'Racing Bicycle Aluminium Frame', '2021-02-19'),
(3, 1, 'Racing Bicycle power brake', '2021-02-19'),
(4, 1, 'Racing Bicycle Magnesium', '2021-02-19'),
(5, 2, 'Baby Bicycle thin tyre', '2021-02-19'),
(6, 2, 'Baby Bicycle Aluminium Frame', '2021-02-19'),
(7, 2, 'Baby Bicycle power brake', '2021-02-19'),
(8, 2, 'Baby Bicycle Magnesium', '2021-02-19'),
(9, 3, 'Hibrid Bicycle thin tyre', '2021-02-19'),
(13, 4, 'Track Bicycle thin tyre', '2021-03-08'),
(14, 4, 'Track Bicycle Aluminium Frame', '2021-02-19'),
(15, 4, 'Track Bicycle power brake', '2021-02-19'),
(16, 4, 'Track Bicycle Magnesium', '2021-02-19'),
(17, 5, 'Fat Bicycle thin tyre', '2021-02-19'),
(18, 5, 'Fat Bicycle Aluminium Frame', '2021-02-19'),
(19, 5, 'Fat Bicycle Power brake', '2021-02-19'),
(20, 5, 'Fat Bicycle Magnesium', '2021-02-19');

-- --------------------------------------------------------

--
-- Table structure for table `bycycle_admin`
--

CREATE TABLE `bycycle_admin` (
  `aid` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bycycle_admin`
--

INSERT INTO `bycycle_admin` (`aid`, `email`, `password`) VALUES
(1, 'mvc_admin@gmail.com', 'a12345');

-- --------------------------------------------------------

--
-- Table structure for table `bycycle_city`
--

CREATE TABLE `bycycle_city` (
  `ctid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `ctname` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bycycle_city`
--

INSERT INTO `bycycle_city` (`ctid`, `sid`, `ctname`) VALUES
(1, 1, 'Rajkot'),
(2, 1, 'Ahemdabad'),
(3, 1, 'Porbandar'),
(4, 1, 'Junagad'),
(5, 2, 'Varansi'),
(6, 2, 'Lucknow');

-- --------------------------------------------------------

--
-- Table structure for table `bycycle_contact`
--

CREATE TABLE `bycycle_contact` (
  `cotact_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bycycle_contact`
--

INSERT INTO `bycycle_contact` (`cotact_id`, `name`, `email`, `mobile`, `message`) VALUES
(1, 'brijesh', 'bkpandey.pandey@gmail.com', 9998003879, 'Hi i does not get your contact number anywhere please send me');

-- --------------------------------------------------------

--
-- Table structure for table `bycycle_customer`
--

CREATE TABLE `bycycle_customer` (
  `custid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `address` text NOT NULL,
  `sid` int(11) NOT NULL,
  `ctid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bycycle_customer`
--

INSERT INTO `bycycle_customer` (`custid`, `username`, `firstname`, `lastname`, `email`, `password`, `photo`, `mobile`, `address`, `sid`, `ctid`) VALUES
(1, 'brijesh', 'brijesh', 'pandey', 'bkpandey.pandey@gmail.com', 'MTIzNDU2', 'uploads/customer/1.jpg', 9998003879, '              150 feeet ring road              ', 1, 1),
(2, 'dhaval007', 'dhaval', 'pandey', 'dhaval@gmail.com', 'MTIzNDU2', 'uploads/customer/login.png', 9998003879, 'rajkot', 1, 1),
(3, 'mansi', 'masni', 'pandya', 'mansi@gmail.com', 'MTIzNDU=', 'uploads/customer/slider4.jpg', 9998003879, 'ji', 1, 1),
(4, 'mayur', 'mayur', 'jani', 'mayur@gmail.com', 'MTIzNDU2', 'uploads/customer/2.jpg', 912121212121, 'rjt', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `bycycle_logo`
--

CREATE TABLE `bycycle_logo` (
  `logoid` int(11) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `added_date` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bycycle_logo`
--

INSERT INTO `bycycle_logo` (`logoid`, `photo`, `added_date`, `status`) VALUES
(1, 'uploads/customer_logo/logo.png', '2021-02-17', '0'),
(2, 'uploads/customer_logo/logo1.jpg', '2021-02-17', '0'),
(3, 'uploads/customer_logo/logo1.png', '2021-02-17', '1');

-- --------------------------------------------------------

--
-- Table structure for table `bycycle_state`
--

CREATE TABLE `bycycle_state` (
  `sid` int(11) NOT NULL,
  `sname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bycycle_state`
--

INSERT INTO `bycycle_state` (`sid`, `sname`) VALUES
(1, 'Gujrat'),
(2, 'Uttar Pradesh');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bycycle_addcategory`
--
ALTER TABLE `bycycle_addcategory`
  ADD PRIMARY KEY (`catid`);

--
-- Indexes for table `bycycle_addproduct`
--
ALTER TABLE `bycycle_addproduct`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `catid` (`catid`),
  ADD KEY `subcatid` (`subcatid`);

--
-- Indexes for table `bycycle_addsubcategory`
--
ALTER TABLE `bycycle_addsubcategory`
  ADD PRIMARY KEY (`subcatid`),
  ADD KEY `catid` (`catid`);

--
-- Indexes for table `bycycle_admin`
--
ALTER TABLE `bycycle_admin`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `bycycle_city`
--
ALTER TABLE `bycycle_city`
  ADD PRIMARY KEY (`ctid`),
  ADD KEY `sid` (`sid`);

--
-- Indexes for table `bycycle_contact`
--
ALTER TABLE `bycycle_contact`
  ADD PRIMARY KEY (`cotact_id`);

--
-- Indexes for table `bycycle_customer`
--
ALTER TABLE `bycycle_customer`
  ADD PRIMARY KEY (`custid`),
  ADD KEY `sid` (`sid`),
  ADD KEY `ctid` (`ctid`);

--
-- Indexes for table `bycycle_logo`
--
ALTER TABLE `bycycle_logo`
  ADD PRIMARY KEY (`logoid`);

--
-- Indexes for table `bycycle_state`
--
ALTER TABLE `bycycle_state`
  ADD PRIMARY KEY (`sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bycycle_addcategory`
--
ALTER TABLE `bycycle_addcategory`
  MODIFY `catid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `bycycle_addproduct`
--
ALTER TABLE `bycycle_addproduct`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bycycle_addsubcategory`
--
ALTER TABLE `bycycle_addsubcategory`
  MODIFY `subcatid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `bycycle_admin`
--
ALTER TABLE `bycycle_admin`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bycycle_city`
--
ALTER TABLE `bycycle_city`
  MODIFY `ctid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `bycycle_contact`
--
ALTER TABLE `bycycle_contact`
  MODIFY `cotact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bycycle_customer`
--
ALTER TABLE `bycycle_customer`
  MODIFY `custid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `bycycle_logo`
--
ALTER TABLE `bycycle_logo`
  MODIFY `logoid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bycycle_state`
--
ALTER TABLE `bycycle_state`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
